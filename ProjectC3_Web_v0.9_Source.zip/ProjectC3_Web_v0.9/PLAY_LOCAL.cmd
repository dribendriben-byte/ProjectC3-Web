@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>&1
if not errorlevel 1 (
  py -3 tools\serve_web.py
) else (
  python tools\serve_web.py
)
pause
