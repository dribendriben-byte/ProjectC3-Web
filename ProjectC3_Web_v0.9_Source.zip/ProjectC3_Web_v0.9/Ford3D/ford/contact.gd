extends Node3D
# Short, batched world-space arcs and shards with one shared mesh per impact.
var geometry := ImmediateMesh.new()
var material := StandardMaterial3D.new()
var age := 0.0
var life := .27
var style := "hit"
var tone := Color("#ffe2a0")

func setup(pos: Vector3, angle: float, kind: String) -> void:
	position=pos
	rotation.y=angle
	style=kind
	match kind:
		"heavy": life=.39; tone=Color("#ffc166")
		"stun": life=.47; tone=Color("#ffe780")
		"guard": life=.58; tone=Color("#8bdfe7")
		"spoil": life=.55; tone=Color("#9deba7")
		"hurt": tone=Color("#ffa08b")
	material.shading_mode=BaseMaterial3D.SHADING_MODE_UNSHADED
	material.vertex_color_use_as_albedo=true
	material.transparency=BaseMaterial3D.TRANSPARENCY_ALPHA
	material.cull_mode=BaseMaterial3D.CULL_DISABLED
	var node := MeshInstance3D.new()
	node.mesh=geometry
	node.cast_shadow=GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(node)
	draw_effect()

func _process(dt: float) -> void:
	age+=dt
	if age>=life: queue_free(); return
	draw_effect()

func triangle(a: Vector3,b: Vector3,c: Vector3) -> void:
	for p in [a,b,c]: geometry.surface_add_vertex(p)

func draw_effect() -> void:
	var t := clampf(age/life,0,1)
	var rune := style in ["guard","spoil"]
	var n := 24
	var r := (.48 if rune else .38)+t*(.57 if style=="heavy" else .39)
	geometry.clear_surfaces()
	geometry.surface_begin(Mesh.PRIMITIVE_TRIANGLES,material)
	geometry.surface_set_color(Color(tone,1-t*t))
	for i in n:
		var a := TAU*i/n if rune else -.6+3.5*i/n
		var b := a+(TAU if rune else 3.5)/n
		var va := Vector3(cos(a),0,sin(a)) if rune else Vector3(cos(a),sin(a),-.32*sin(a))
		var vb := Vector3(cos(b),0,sin(b)) if rune else Vector3(cos(b),sin(b),-.32*sin(b))
		var base := Vector3.UP*(t*.45 if rune else .04)
		var width := (.065 if rune else .13*sin(PI*(i+.5)/n))*(1-t)
		triangle(base+va*r,base+vb*r,base+vb*(r+width))
		triangle(base+va*r,base+vb*(r+width),base+va*(r+width))
	for i in (9 if style=="heavy" else 6):
		var a := i*2.40
		var dir := Vector3(cos(a),.4+sin(i*.9)*.6,sin(a)).normalized()
		var p := dir*(.12+t*.64)
		var side := Vector3(-dir.z,0,dir.x)*.043*(1-t)
		triangle(p+side,p-side,p+dir*.21)
	geometry.surface_end()
