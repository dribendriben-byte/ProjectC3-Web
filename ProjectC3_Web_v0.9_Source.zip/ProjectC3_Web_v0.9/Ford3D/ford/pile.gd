extends Node3D
const Icons=preload("res://field/icon_library.gd")
var reward: Dictionary
var point: Vector2

func setup(record: Dictionary,where: Vector3) -> void:
	reward=record
	point=Vector2(where.x,where.z)
	position=where
	var coin:=CylinderMesh.new()
	coin.top_radius=.16
	coin.bottom_radius=.16
	coin.height=.052
	coin.radial_segments=10
	var gold:=StandardMaterial3D.new()
	gold.albedo_color=Color("#eac268")
	gold.metallic=.28
	coin.material=gold
	for i in 6:
		var node:=MeshInstance3D.new()
		node.mesh=coin
		add_child(node)
		node.position=Vector3(cos(i*2.3)*.15,.045+i*.032,sin(i*2.3)*.14)
	var ids:Array=record.items.keys()
	if ids.is_empty(): ids.append("adena")
	for i in ids.size():
		var icon:=Sprite3D.new()
		icon.texture=Icons.get_icon(ids[i])
		icon.billboard=BaseMaterial3D.BILLBOARD_ENABLED
		icon.pixel_size=.0044
		icon.position=Vector3((i-(ids.size()-1)*.5)*.44,.62,0)
		icon.shaded=false
		add_child(icon)
