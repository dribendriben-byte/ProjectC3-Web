extends Node

const PIECE = preload("res://ford/audio/spring.ogg")
const CLIPS := {
	"hit":preload("res://ford/audio/hit.wav"),"heavy":preload("res://ford/audio/heavy.wav"),
	"hurt":preload("res://ford/audio/hurt.wav"),"step":preload("res://ford/audio/step.wav"),
	"loot":preload("res://ford/audio/loot.wav"),"ward":preload("res://ford/audio/ward.wav")
}
const LEVELS := {"hit":-7,"heavy":-6,"hurt":-14,"step":-22,"loot":-12,"ward":-10}
var music := AudioStreamPlayer.new()
var voices: Array[AudioStreamPlayer] = []
var index := 0
var muted := false
var resume_at := 0.0

func _ready() -> void:
	music.stream=PIECE
	music.volume_db=-11
	add_child(music)
	for i in 5:
		var voice := AudioStreamPlayer.new()
		add_child(voice)
		voices.append(voice)

func set_muted(value: bool) -> void:
	muted=value
	if muted:
		if music.playing: resume_at=music.get_playback_position()
		music.stop()
		for voice in voices: voice.stop()
	elif not music.playing:
		music.play(resume_at)

func effect(id: String) -> void:
	if muted: return
	var voice := voices[index]
	index=(index+1)%voices.size()
	voice.stream=CLIPS[id]
	voice.volume_db=LEVELS[id]
	voice.pitch_scale=randf_range(.94,1.06)
	voice.play()

func _exit_tree() -> void:
	music.stop()
	for voice in voices: voice.stop()
