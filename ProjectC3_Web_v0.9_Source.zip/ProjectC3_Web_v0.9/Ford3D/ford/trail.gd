extends RefCounted
const Ground = preload("res://ford/ground.gd")
var surface := SurfaceTool.new()
var rng := RandomNumberGenerator.new()

func triangle(a: Vector3,b: Vector3,c: Vector3,color: Color) -> void:
	var normal := (b-a).cross(c-a).normalized()
	for point in [a,b,c]:
		surface.set_color(color)
		surface.set_normal(normal)
		surface.add_vertex(point)

func patch(x: float,z: float,r: float,stretch: float,color: Color) -> void:
	var y := Ground.height(Vector2(x,z))+.085
	var center := Vector3(x,y,z)
	var turn := rng.randf()*TAU
	for i in 5:
		var a := turn+i*TAU/5
		var b := a+TAU/5
		triangle(center,center+Vector3(cos(b)*r,0,sin(b)*r*stretch),center+Vector3(cos(a)*r,0,sin(a)*r*stretch),color)

func pole(a: Vector3,b: Vector3,r: float,c: Color) -> void:
	var axis := a.direction_to(b)
	var u := axis.cross(Vector3.FORWARD if absf(axis.z)<.9 else Vector3.RIGHT).normalized()
	var v := axis.cross(u)
	for i in 6:
		var p := (u*cos(i*TAU/6)+v*sin(i*TAU/6))*r
		var q := (u*cos((i+1)*TAU/6)+v*sin((i+1)*TAU/6))*r
		triangle(a+p,b+p,b+q,c)
		triangle(a+p,b+q,a+q,c)
		triangle(b,b+p,b+q,c)

func dress(root: Node3D) -> void:
	surface.begin(Mesh.PRIMITIVE_TRIANGLES)
	rng.seed=5152
	# Rounded stones along the cart tracks and low reeds at the water's edge.
	for i in 460:
		var x := rng.randf_range(-23,23)
		if absf(x)<3: continue
		var track := .65*sin(absf(x)*.33)
		var z := track+rng.randf_range(-1.02,1.02)
		patch(x,z,rng.randf_range(.035,.14),rng.randf_range(.35,.74),Color("#bba077").lerp(Color("#dfc99b"),rng.randf()))
	for i in 100:
		var z := rng.randf_range(-24,24)
		if absf(z)<2: continue
		var x := Ground.river(z)+rng.randf_range(1.8,2.25)*(-1 if i%2 else 1)
		for j in 5:
			var p := Vector3(x+rng.randf_range(-.19,.19),-.17,z+rng.randf_range(-.16,.16))
			var tip := p+Vector3(rng.randf_range(-.12,.12),rng.randf_range(.25,.68),rng.randf_range(-.13,.13))
			triangle(p-Vector3(.035,0,0),tip,p+Vector3(.035,0,.025),Color("#7e925a"))
			if j%3==0: pole(tip-Vector3.UP*.09,tip+Vector3.UP*.055,.022,Color("#926a41"))
	# Twin field standards, stitched with a river chevron.
	for foot in [Vector2(-7.7,-1.5),Vector2(3.45,-1.78)]:
		var p := Ground.point(foot)
		pole(p,p+Vector3.UP*2.82,.07,Color("#806244"))
		pole(p+Vector3(-.49,2.60,0),p+Vector3(.51,2.60,0),.045,Color("#b8955a"))
		var a := p+Vector3(-.39,2.56,0)
		var b := p+Vector3(.39,2.56,0)
		var c := p+Vector3(.37,1.83,.02)
		var d := p+Vector3(-.38,1.91,.03)
		triangle(a,b,c,Color("#365d64"))
		triangle(a,c,d,Color("#426c6d"))
		triangle(c,d,p+Vector3(.01,1.55,.05),Color("#3c6668"))
		for sign_ in [-1,1]:
			var signf := float(sign_)
			triangle(p+Vector3(0,1.99,.07),p+Vector3(signf*.29,2.27,.07),p+Vector3(signf*.23,2.10,.07),Color("#edc872"))
	var mat := StandardMaterial3D.new()
	mat.vertex_color_use_as_albedo=true
	mat.vertex_color_is_srgb=true
	mat.cull_mode=BaseMaterial3D.CULL_DISABLED
	mat.roughness=1
	surface.set_material(mat)
	var decor := MeshInstance3D.new()
	decor.mesh=surface.commit()
	root.add_child(decor)
