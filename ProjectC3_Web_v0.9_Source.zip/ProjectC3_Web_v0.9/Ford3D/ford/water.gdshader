shader_type spatial;
render_mode cull_disabled;
varying vec3 local_pos;
void vertex() { local_pos = VERTEX; }
void fragment(){
	vec2 p=local_pos.xz;
	float s=sin(p.y*4.9+1.5*sin(p.x*2.1+p.y*.64)-TIME*1.6);
	float dash=sin(p.x*2.3 + p.y*2.7+1.6*sin(p.y*1.4)-TIME*.7);
	float highlight=smoothstep(.94,1.0,s)*smoothstep(.24,.70,dash);
	float bank=abs(p.x-(.105*p.y+1.15*sin(p.y*.16)));
	vec3 color=mix(vec3(.104,.30,.30),vec3(.19,.42,.39),smoothstep(.2,1.95,bank));
	ALBEDO=mix(color,vec3(.54,.70,.60),highlight*.52);
	ROUGHNESS=.82;
}
