extends RefCounted

static func piece(parent: Node3D,at: Vector3,extent: Vector3,color: Color,tilt:=0.0) -> void:
	var shape:=BoxMesh.new()
	shape.size=extent
	var mat:=StandardMaterial3D.new()
	mat.albedo_color=color
	shape.material=mat
	var part:=MeshInstance3D.new()
	part.mesh=shape
	parent.add_child(part)
	part.position=at
	part.rotation.z=tilt

static func fit(model: Node3D,gear: Dictionary) -> void:
	var body:Node3D=model.find_child("Body",true,false)
	if body==null: return
	var old:=body.get_node_or_null("Outfit")
	if old!=null: body.remove_child(old); old.queue_free()
	var outfit:=Node3D.new()
	outfit.name="Outfit"
	body.add_child(outfit)
	if gear.get("Грудь","")=="cuirass":
		for i in 5:
			var offset:float=(i-2)*.153
			var z:=.34-.065*absf(i-2)
			piece(outfit,Vector3(offset,1.17,z),Vector3(.147,.53-.055*absf(i-2),.10),Color("#bd8955").darkened((i%2)*.11),offset*.16)
			piece(outfit,Vector3(offset,1.17,-z),Vector3(.15,.47,.08),Color("#966b46"),offset*.13)
		piece(outfit,Vector3(0,1.19,.405),Vector3(.72,.062,.034),Color("#704e35"),-.36)
		piece(outfit,Vector3(.06,1.17,.434),Vector3(.09,.09,.034),Color("#e3b672"),-.36)
	for side in ["ArmL","ArmR"]:
		var arm:Node3D=model.find_child(side,true,false)
		var cuff:=arm.get_node_or_null("Wrist")
		if cuff: arm.remove_child(cuff); cuff.queue_free()
		if gear.get("Запястья","")=="bracer":
			var wrist:=Node3D.new()
			wrist.name="Wrist"
			arm.add_child(wrist)
			piece(wrist,Vector3(0,-.37,0),Vector3(.31,.14,.30),Color("#a0774a"))
