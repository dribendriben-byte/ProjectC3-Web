extends Node3D
const MODEL := preload("res://ford/models/rootling.glb")
const Ground := preload("res://ford/ground.gd")
var rank := 1
var hp := 33
var max_hp := 33
var home := Vector2.ZERO
var spoiled := false
var stun := 0.0
var respawn := 0.0
var phase := 0.0
var cycle:=0.0
var contacts: Array[Vector3]=[]
var swing := 0.0
var limbs: Array[Node3D] = []
var torso: Node3D

func setup(p: Vector2, level: int, index: int) -> void:
	home=p
	rank=level
	max_hp=26+level*7
	hp=max_hp
	phase=index*1.71
	position=Ground.point(p)
	rotation.y=-1.1+sin(phase)*.65
	var model := MODEL.instantiate()
	add_child(model)
	torso=model.find_child("Body",true,false)
	for name_ in ["FrontL","FrontR","BackL","BackR"]:
		limbs.append(model.find_child(name_,true,false))
		contacts.append(limbs.back().position)

func flat() -> Vector2:
	return Vector2(position.x,position.z)

func tick(dt: float, engaged: bool, player: Vector2) -> void:
	if hp<=0:
		respawn-=dt
		if respawn<=0:
			hp=max_hp; spoiled=false; stun=0; position=Ground.point(home); show()
		return
	var previous:=flat()
	phase+=dt
	stun=maxf(0,stun-dt)
	swing=maxf(0,swing-dt)
	if engaged:
		var dir := player-flat()
		if dir.length_squared()>.04: rotation.y=lerp_angle(rotation.y,atan2(dir.x,dir.y),minf(1,dt*6))
	else:
		var goal:=home+Vector2(.72*cos(phase*.72),.64*sin(phase*.58))
		position=Ground.point(flat().move_toward(goal,dt*.68))
	var movement:=flat()-previous
	if movement.length_squared()>.000001:
		rotation.y=lerp_angle(rotation.y,atan2(movement.x,movement.y),minf(1,dt*5))
	cycle+=movement.length()*8.3
	var walking:=clampf(movement.length()/maxf(dt*.62,.001),0,1)
	torso.position.y=.024*sin(phase*2.1)+walking*(.05*absf(sin(cycle))-.035*pow(absf(cos(cycle)),6))
	torso.rotation.z=.064*sin(cycle)*walking
	torso.rotation.x=-.29*sin(PI*swing/.35) if swing>0 else .04*walking
	for i in limbs.size():
		var angle:=cycle+PI*int(i in [1,2])
		limbs[i].rotation.x=.34*sin(angle)*walking
		limbs[i].position=contacts[i]+Vector3.UP*.09*maxf(0,-cos(angle))*walking

func hurt(amount: int) -> bool:
	hp=maxi(0,hp-amount)
	if hp==0:
		respawn=15; hide()
	return hp==0
