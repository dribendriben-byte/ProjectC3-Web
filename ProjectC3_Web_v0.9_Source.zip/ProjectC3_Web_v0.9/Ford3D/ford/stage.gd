extends RefCounted
const Ground = preload("res://ford/ground.gd")

static func build(root: Node3D) -> void:
	var world := WorldEnvironment.new()
	var env := Environment.new()
	env.background_mode=Environment.BG_COLOR
	env.background_color=Color("#b8d3d5")
	env.ambient_light_source=Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color=Color("#e1e7df")
	env.ambient_light_energy=.78
	env.fog_enabled=true
	env.fog_light_color=Color("#a6c2bd")
	env.fog_density=.006
	world.environment=env
	root.add_child(world)
	var strip := SurfaceTool.new()
	strip.begin(Mesh.PRIMITIVE_TRIANGLES)
	var water := ShaderMaterial.new()
	water.shader=preload("res://ford/water.gdshader")
	strip.set_material(water)
	for z in range(-70,70):
		var x := Ground.river(z)
		var nx := Ground.river(z+1)
		for v in [Vector3(x-2.65,-.21,z),Vector3(nx-2.65,-.21,z+1),Vector3(nx+2.65,-.21,z+1),Vector3(x-2.65,-.21,z),Vector3(nx+2.65,-.21,z+1),Vector3(x+2.65,-.21,z)]:
			strip.set_normal(Vector3.UP)
			strip.add_vertex(v)
	var surface := MeshInstance3D.new()
	surface.mesh=strip.commit()
	surface.cast_shadow=GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	root.add_child(surface)

static func ring(root: Node3D, radius: float, color: Color) -> MeshInstance3D:
	var mesh := TorusMesh.new()
	mesh.inner_radius=radius-.045
	mesh.outer_radius=radius
	mesh.rings=36
	mesh.ring_segments=5
	var mat := StandardMaterial3D.new()
	mat.shading_mode=BaseMaterial3D.SHADING_MODE_UNSHADED
	mat.albedo_color=color
	mesh.material=mat
	var node := MeshInstance3D.new()
	node.mesh=mesh
	node.cast_shadow=GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	root.add_child(node)
	node.hide()
	return node
