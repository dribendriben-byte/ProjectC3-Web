@tool
extends EditorScenePostImport

# The GLB meshes share one painted material per model. Their linear vertex
# colors hold the individual colors of rock, leaves, cloth and armor.
func _post_import(scene: Node) -> Object:
	for node in scene.find_children("*","MeshInstance3D",true,false):
		for i in node.mesh.get_surface_count():
			var material: StandardMaterial3D = node.mesh.surface_get_material(i)
			if material:
				material.vertex_color_use_as_albedo=true
				material.vertex_color_is_srgb=false
	return scene
