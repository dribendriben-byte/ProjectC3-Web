extends Node3D

const Ground = preload("res://ford/ground.gd")
const Stage = preload("res://ford/stage.gd")
const Beast = preload("res://ford/creature.gd")
const Hud = preload("res://field/hud.gd")
const Hero = preload("res://field/careers.gd")
const Skills = preload("res://field/skills.gd")
const Loot = preload("res://field/loot.gd")
const Actions = preload("res://field/actions.gd")
const Contact = preload("res://ford/contact.gd")
const START := Vector2(-5,1.7)
const REACH := 1.52
const SPEED := 3.75

@onready var hero: Node3D = $Warden
@onready var cam: Camera3D = $Camera
var ground := Ground.new()
var hud := Hud.new()
var profile := Hero.new()
var rng := RandomNumberGenerator.new()
var spells: Array[Dictionary]
var mobs: Array[Beast] = []
var target: Beast
var route := PackedVector2Array()
var cursor: MeshInstance3D
var target_ring: MeshInstance3D
var wheel: Node3D
var torso: Node3D
var limbs: Array[Node3D] = []
var yaw := .32
var distance := 16.2
var focus := Vector3.ZERO
var target_pos := Vector2.INF
var actor := START
var heading := 1.55
var walk_phase := 0.0
var swing := 0.0
var attack_wait := 0.0
var hurt_wait := .8
var shield := 0.0
var regen := 0.0
var hp := 0
var mp := 0
var pending := ""
var town:=false
var city_ground:=Ground.new(true)
var field_ground=ground
var city_model: Node3D
var town_transition:=false
var piles: Array[Node3D]=[]
var collecting: Node3D
var wanted_yaw:=.32
var pitch:=.63
var wanted_pitch:=.63
var wanted_distance:=16.2
var finger:=-1
var finger_origin:=Vector2.ZERO
var finger_last:=Vector2.ZERO
var orbiting:=false
var turning:=0
var right_drag:=false
var gait_blend:=0.0
var foot_positions: Array[Vector3]=[]
var engaged := false
var catalog := {}
var sound := preload("res://ford/audio.gd").new()
var stride := 0.0
var cooldowns: Array[float] = [0,0,0,0,0,0,0]
var refresh_time := 0.0

func _ready() -> void:
	Stage.build(self)
	preload("res://ford/trail.gd").new().dress(self)
	profile.race="Гном"
	profile.origin="Подгорный боец"
	profile.restore()
	spells=Skills.book(profile)
	catalog=Actions.build(spells)
	profile.hotbar=Actions.normalize(profile.hotbar,catalog,profile)
	add_child(sound)
	sound.set_muted(profile.muted)
	hp=profile.hp_max()
	mp=profile.mana_max()
	torso=hero.find_child("Body",true,false)
	for name_ in ["LegL","LegR","ArmL","ArmR"]:
		limbs.append(hero.find_child(name_,true,false))
	wheel=$Landscape.find_child("Wheel",true,false)
	hero.position=Ground.point(actor)
	hero.rotation.y=heading
	for limb in limbs: foot_positions.append(limb.position)
	preload("res://ford/worn.gd").fit(hero,profile.equipment)
	city_model=preload("res://ford/models/city.glb").instantiate()
	add_child(city_model)
	city_model.position.x=180
	city_model.hide()
	for rec in profile.ground_loot:
		if rec is Dictionary and rec.has("place") and rec.has("items"): spawn_pile(rec)
	target_ring=Stage.ring(self,.88,Color("#f9c46a"))
	cursor=Stage.ring(self,.43,Color("#eef2ae"))
	var homes := [Vector2(4,-1.3),Vector2(6.4,.85),Vector2(5.3,-4),Vector2(9,-2.7),Vector2(11,3),Vector2(11,-6),Vector2(14,6),Vector2(16,-3),Vector2(12,8)]
	for i in homes.size():
		var mob := Beast.new()
		add_child(mob)
		mob.setup(homes[i],1+floori(i/3.0),i)
		mobs.append(mob)
	add_child(hud)
	hud.shade.hide()
	hud.playing=true
	hud.gateway.pressed.connect(travel_city)
	hud.gateway.tooltip_text="Дорога между бродом и южными воротами"
	for i in 4:
		var key := hud.button(["↶","↷","−","+"][i])
		key.tooltip_text=["Камера влево","Камера вправо","Отдалить","Приблизить"][i]
		hud.place(hud.ui,key,Rect2(758+i*47,157,44,40))
		hud.ui.move_child(key,hud.desks.get_index())
		if i<2:
			key.button_down.connect(func(): turning=-1 if i==0 else 1)
			key.button_up.connect(func(): turning=0)
		else: key.pressed.connect(_camera_action.bind(i))
	hud.skill_pressed.connect(use_slot)
	hud.swap_requested.connect(func(from: int,to: int):
		var action: String=profile.hotbar[from]
		if action.is_empty(): return
		profile.hotbar[from]=profile.hotbar[to]
		profile.hotbar[to]=action
		save_hero()
		update_ui())
	hud.layout_changed.connect(func(): save_hero(); update_ui())
	hud.sound_requested.connect(func():
		profile.muted=not profile.muted
		sound.set_muted(profile.muted)
		update_sound_button()
		save_hero())
	update_sound_button()
	hud.window_requested.connect(open_window)
	hud.careers_pressed.connect(func(): hud.show_careers(profile))
	hud.equip_requested.connect(func(id): 
		if profile.toggle_item(id):
			preload("res://ford/worn.gd").fit(hero,profile.equipment)
			hud.sheet.refresh(true)
			hud.bag.refresh()
			save_hero()
			update_ui())
	hud.train_requested.connect(func(i):
		if profile.learn(spells[i]): save_hero(); hud.book_editor.queue_redraw())
	hud.transfer_requested.connect(func(job):
		if profile.promote(job):
			spells=Skills.book(profile)
			catalog=Actions.build(spells)
			save_hero()
			hud.shade.hide()
			update_ui())
	focus=hero.position+Vector3(2,0,-.6)
	update_camera()
	hud.feed.text="Выбери Корневика, затем нажми удар на панели."
	update_ui()

func update_sound_button() -> void:
	hud.sound_button.icon=hud.Icons.get_icon("mute" if profile.muted else "sound")
	hud.sound_button.tooltip_text="Включить звук" if profile.muted else "Выключить звук"

func save_hero() -> void:
	if profile.store_character()!=OK: hud.feed.text="Не удалось записать сохранение."

func open_window(kind: String) -> void:
	match kind:
		"Персонаж": hud.show_stats(profile,hp,mp,SPEED)
		"Умения": hud.show_book(profile,catalog)
		"Инвентарь": hud.show_bag(profile)

func travel_city() -> void:
	if town_transition or hud.shade.visible: return
	var gate:=Vector2(180,36) if town else START
	if actor.distance_to(gate)>6: return
	town_transition=true
	hud.stick.reset()
	clear_target()
	hud.veil.modulate.a=0
	hud.veil.show()
	var fade:=create_tween()
	fade.tween_property(hud.veil,"modulate:a",1,.22)
	fade.tween_callback(switch_region)
	fade.tween_property(hud.veil,"modulate:a",0,.3)
	fade.tween_callback(func(): hud.veil.hide(); town_transition=false)

func switch_region() -> void:
	town=not town
	city_model.visible=town
	ground=city_ground if town else field_ground
	actor=Vector2(180,34.5) if town else START
	for pile in piles: pile.visible=not town
	hud.radar.town=town
	hero.position=Ground.point(actor)
	focus=hero.position+Vector3.UP*.43
	yaw=.2
	wanted_yaw=yaw
	heading=PI if town else 1.55
	hero.rotation.y=heading
	hud.feed.text="Вересковый Град · Южные ворота" if town else "Травяной брод · Застава"
	update_camera()
	update_ui()

func _camera_action(i: int) -> void:
	wanted_distance=clampf(wanted_distance+(2 if i==2 else -2),7,26)

func update_camera() -> void:
	var offset:=Vector3(sin(yaw)*cos(pitch),sin(pitch),cos(yaw)*cos(pitch))
	cam.position=focus+offset*distance
	cam.look_at(focus)

func orbit(delta: Vector2) -> void:
	wanted_yaw-=delta.x*.006
	wanted_pitch=clampf(wanted_pitch+delta.y*.005,.20,1.29)

func _process(dt: float) -> void:
	if not is_node_ready() or hud.shade.visible or town_transition: return
	var keyboard:=int(Input.is_physical_key_pressed(KEY_E))-int(Input.is_physical_key_pressed(KEY_Q))
	wanted_yaw+=(turning+keyboard)*1.5*dt
	var blend:=1-exp(-14*dt)
	yaw=lerp_angle(yaw,wanted_yaw,blend)
	pitch=lerpf(pitch,wanted_pitch,blend)
	distance=lerpf(distance,wanted_distance,blend)
	focus=focus.lerp(hero.position+Vector3(0,.8,0),1-exp(-7*dt))
	update_camera()

func _input(e: InputEvent) -> void:
	if not is_node_ready(): return
	if hud.shade.visible or town_transition: finger=-1; right_drag=false; return
	if right_drag and e is InputEventMouseMotion:
		orbit(e.relative)
		get_viewport().set_input_as_handled()
	elif right_drag and e is InputEventMouseButton and e.button_index==MOUSE_BUTTON_RIGHT and not e.pressed:
		right_drag=false
		get_viewport().set_input_as_handled()
	elif e is InputEventScreenDrag and e.index==finger:
		var p:Vector2=e.position
		if orbiting or p.distance_to(finger_origin)>8:
			orbit(p-finger_last)
			orbiting=true
			finger_last=p
		get_viewport().set_input_as_handled()
	elif e is InputEventScreenTouch and e.index==finger and not e.pressed:
		finger=-1
		if not e.canceled and not orbiting and e.position.distance_to(finger_origin)<=8: select_screen(e.position)
		get_viewport().set_input_as_handled()

func _notification(what: int) -> void:
	if what==NOTIFICATION_APPLICATION_FOCUS_OUT:
		finger=-1
		right_drag=false
		turning=0

func _unhandled_input(e: InputEvent) -> void:
	if not is_node_ready() or hud.shade.visible or town_transition: return
	if e is InputEventScreenTouch and e.pressed and finger<0:
		finger=e.index
		finger_origin=e.position
		finger_last=e.position
		orbiting=false
		get_viewport().set_input_as_handled()
	elif e is InputEventMouseButton and e.pressed and e.device!=InputEvent.DEVICE_ID_EMULATION:
		match e.button_index:
			MOUSE_BUTTON_RIGHT: right_drag=true
			MOUSE_BUTTON_LEFT: select_screen(e.position)
			MOUSE_BUTTON_WHEEL_UP: _camera_action(3)
			MOUSE_BUTTON_WHEEL_DOWN: _camera_action(2)
	elif e is InputEventKey and e.pressed and not e.echo:
		if e.keycode>=KEY_1 and e.keycode<=KEY_7: use_slot(e.keycode-KEY_1)
		match e.keycode:
			KEY_I: open_window("Инвентарь")
			KEY_C: open_window("Персонаж")
			KEY_K: open_window("Умения")

func select_screen(screen: Vector2) -> void:
	var best: Beast
	var nearest_depth := INF
	for mob in mobs:
		if town or mob.hp<=0 or cam.is_position_behind(mob.position): continue
		var head := cam.unproject_position(mob.position+Vector3.UP*1.55)
		var foot := cam.unproject_position(mob.position)
		var scale_ := maxf(20,head.distance_to(foot))
		var offset := (screen-(head+foot)*.5)/Vector2(maxf(13,scale_*.55),maxf(14,scale_*.59))
		var depth := cam.position.distance_to(mob.position)
		if offset.length()<=1 and depth<nearest_depth:
			best=mob
			nearest_depth=depth
	if not town:
		for pile in piles:
			if cam.is_position_behind(pile.position): continue
			var center:=cam.unproject_position(pile.position+Vector3.UP*.52)
			if screen.distance_to(center)<19 and (best==null or cam.position.distance_to(pile.position)<nearest_depth):
				request_pickup(pile)
				return
	if best!=null:
		select_target(best)
		return
	var origin := cam.project_ray_origin(screen)
	var ray := cam.project_ray_normal(screen)
	if ray.y>=-.01: return
	var p := origin+ray*(-origin.y/ray.y)
	for i in 3:
		p=origin+ray*((Ground.height(Vector2(p.x,p.z))-origin.y)/ray.y)
	walk_to(Vector2(p.x,p.z))

func walk_to(where: Vector2) -> void:
	var path := ground.route(actor,where)
	if path.is_empty(): return
	clear_target()
	route=path
	cursor.position=Ground.point(where)+Vector3.UP*.065
	cursor.show()

func clear_target() -> void:
	target=null
	pending=""
	collecting=null
	engaged=false
	target_ring.hide()
	route.clear()
	cursor.hide()

func plan_chase() -> void:
	target_pos=target.flat()
	route=ground.route(actor,target_pos)

func select_target(mob: Beast) -> void:
	if target!=mob:
		clear_target()
		target=mob
		hurt_wait=.9
		hud.feed.text="Цель выбрана · Корневик"
	update_ui()

func next_target() -> void:
	var nearby: Array[Beast]=[]
	for mob in mobs:
		if not town and mob.hp>0 and actor.distance_to(mob.flat())<=12: nearby.append(mob)
	if nearby.is_empty():
		hud.feed.text="В радиусе 12 м целей нет."
		return
	nearby.sort_custom(func(a,b): return actor.distance_squared_to(a.flat())<actor.distance_squared_to(b.flat()))
	select_target(nearby[(nearby.find(target)+1)%nearby.size()])

func use_slot(i: int) -> void:
	if hud.shade.visible or i<0 or i>=7: return
	var id: String=profile.hotbar[i]
	if id.is_empty():
		hud.show_book(profile,catalog)
		return
	if id=="cycle":
		next_target()
		hud.slots[i].flash_cast()
		return
	if id=="pickup":
		var nearest:Node3D
		var radius:=12.01
		for pile in piles:
			var gap:=actor.distance_to(pile.point)
			if pile.visible and gap<radius: radius=gap; nearest=pile
		if nearest: request_pickup(nearest); flash("pickup")
		else: hud.feed.text="Поблизости нет добычи."
		return
	var sk: Dictionary=catalog[id]
	var offensive: bool=not sk.has("index") or Skills.offensive(sk.effect)
	if offensive and target==null:
		hud.feed.text="Сначала выбери цель."
		return
	if sk.has("index"):
		if not profile.knows(sk) or profile.level()<sk.level: return
		if cooldowns[sk.index]>0:
			hud.feed.text="%s · ещё %d с" % [sk.name,ceili(cooldowns[sk.index])]
			return
		if mp<sk.mp:
			hud.feed.text="Недостаточно маны."
			return
		if sk.effect=="spoil" and target.spoiled:
			hud.feed.text="Цель уже помечена."
			return
	elif id=="hit" and attack_wait>0: return
	if offensive:
		pending=id
		cursor.hide()
		if actor.distance_to(target.flat())>REACH: plan_chase()
	else: cast(sk)
	update_ui()

func flash(id: String) -> void:
	var slot:=profile.hotbar.find(id)
	if slot>=0: hud.slots[slot].flash_cast()

func contact(p: Vector3,kind: String) -> void:
	var particles:=Contact.new()
	add_child(particles)
	particles.setup(p,heading,kind)

func cast(sk: Dictionary) -> void:
	cooldowns[sk.index]=sk.cd
	mp-=int(sk.mp)
	flash("spell/"+str(sk.name))
	hud.feed.text=sk.name
	match sk.effect:
		"guard":
			shield=7
			sound.effect("ward")
			contact(hero.position+Vector3.UP*.55,"guard")
		"spoil":
			target.spoiled=true
			engaged=true
			sound.effect("ward")
			contact(target.position+Vector3.UP*.35,"spoil")
			float_word(target.position,"Спойл",Color("#f2cd82"))
		_:
			if sk.effect=="stun": target.stun=2
			attack(profile.damage()*(3 if sk.effect=="crush" else 2),"stun" if sk.effect=="stun" else "heavy")

func attack(amount: int,kind: String="hit") -> void:
	engaged=true
	sound.effect("hit" if kind=="hit" else "heavy")
	contact(target.position+Vector3.UP*.77,kind)
	swing=.38
	attack_wait=1.02
	float_word(target.position,"−%d" % amount,Color("#fff3c4"))
	if not target.hurt(amount): return
	var reward := Loot.roll(0,target.rank,.04*profile.role_score("Добыча"),target.spoiled,rng)
	reward["place"]=target.flat()
	profile.ground_loot.append(reward)
	spawn_pile(reward)
	var gain := Loot.xp_for(0,target.rank,profile.level())
	var old_level := profile.level()
	profile.earn(gain)
	var msg := "+%d EXP · Добыча на земле" % gain
	if profile.level()>old_level:
		hp=profile.hp_max()
		mp=profile.mana_max()
		msg+="  ·  Уровень %d!" % profile.level()
	hud.feed.text=msg
	clear_target()
	save_hero()
	update_ui()

func spawn_pile(record: Dictionary) -> void:
	var pile:=preload("res://ford/pile.gd").new()
	add_child(pile)
	pile.setup(record,Ground.point(record.place))
	piles.append(pile)

func request_pickup(pile: Node3D) -> void:
	clear_target()
	collecting=pile
	if actor.distance_to(pile.point)>1.65:
		route=ground.route(actor,pile.point)
		if route.is_empty(): collecting=null; hud.feed.text="Не удалось подойти к добыче."

func take_pile() -> void:
	var pile:=collecting
	collecting=null
	route.clear()
	profile.collect(pile.reward)
	profile.ground_loot.erase(pile.reward)
	piles.erase(pile)
	var msg:="Подобрано · %d аден" % pile.reward.adena
	for id in pile.reward.items: msg+=" · %s ×%d" % [Loot.ITEMS[id][0],pile.reward.items[id]]
	hud.feed.text=msg
	pile.queue_free()
	sound.effect("loot")
	save_hero()
	hud.bag.refresh()

func float_word(p: Vector3, message: String, tint: Color) -> void:
	var text := Label3D.new()
	text.text=message
	text.font_size=46
	text.pixel_size=.006
	text.billboard=BaseMaterial3D.BILLBOARD_ENABLED
	text.modulate=tint
	text.outline_size=7
	add_child(text)
	text.position=p+Vector3.UP*1.65
	var fade := text.create_tween()
	fade.tween_property(text,"position:y",text.position.y+.85,.7)
	fade.tween_callback(text.queue_free)

func _physics_process(dt: float) -> void:
	if hud.shade.visible or town_transition: return
	if wheel!=null: wheel.rotate_x(dt*.45)
	var prev := actor
	var axis := hud.stick.axis
	if axis.is_zero_approx():
		axis=Input.get_vector("ui_left","ui_right","ui_up","ui_down")
		if axis.is_zero_approx():
			axis=Vector2(int(Input.is_physical_key_pressed(KEY_D))-int(Input.is_physical_key_pressed(KEY_A)),int(Input.is_physical_key_pressed(KEY_S))-int(Input.is_physical_key_pressed(KEY_W))).limit_length()
	for i in cooldowns.size(): cooldowns[i]=maxf(0,cooldowns[i]-dt)
	attack_wait=maxf(0,attack_wait-dt)
	swing=maxf(0,swing-dt)
	shield=maxf(0,shield-dt)
	if not axis.is_zero_approx():
		clear_target()
		var delta := axis.rotated(-yaw)*SPEED*dt
		if ground.legal(actor+delta): actor+=delta
		elif ground.legal(actor+Vector2(delta.x,0)): actor.x+=delta.x
		elif ground.legal(actor+Vector2(0,delta.y)): actor.y+=delta.y
	elif target!=null and pending!="" and actor.distance_to(target.flat())<=REACH:
		route.clear()
		var d := target.flat()-actor
		heading=atan2(d.x,d.y)
		if pending.begins_with("spell/"):
			var sk: Dictionary=catalog[pending]
			pending=""
			cast(sk)
		elif attack_wait<=0:
			flash("hit")
			pending=""
			attack(profile.damage())
	else:
		if target!=null and pending!="" and (route.is_empty() or target_pos.distance_to(target.flat())>.5): plan_chase()
		var travel := dt*SPEED
		while travel>0 and not route.is_empty():
			var gap := actor.distance_to(route[0])
			if gap<=travel:
				actor=route[0]
				route.remove_at(0)
				travel-=gap
			else:
				actor=actor.move_toward(route[0],travel)
				travel=0
		if route.is_empty(): cursor.hide()
	if collecting!=null and actor.distance_to(collecting.point)<=1.65: take_pile()
	if not town:
		for mob in mobs: mob.tick(dt,mob==target and engaged,actor)
	if target!=null:
		target_ring.position=target.position+Vector3.UP*.08
		target_ring.show()
		if engaged and actor.distance_to(target.flat())<=REACH and target.stun<=0:
			hurt_wait-=dt
			if hurt_wait<=0:
				target.swing=.35
				sound.effect("hurt")
				contact(hero.position+Vector3.UP*.91,"hurt")
				hurt_wait=1.55
				var damage := maxi(1,3+target.rank*2-profile.defense())
				hp-=maxi(1,ceili(damage*(.5 if shield>0 else 1.0)))
				if hp<=0:
					clear_target()
					actor=START
					hp=profile.hp_max()
					mp=profile.mana_max()
					hud.feed.text="Стража вернула тебя к заставе."
	regen+=dt
	if regen>=1:
		regen-=1
		mp=mini(profile.mana_max(),mp+2)
		if not engaged: hp=mini(profile.hp_max(),hp+2)
	var motion := actor-prev
	var moving := motion.length()>.002
	if moving:
		heading=atan2(motion.x,motion.y)
		stride+=minf(motion.length(),SPEED*dt)
		if stride>.80:
			sound.effect("step")
			stride=fmod(stride,.80)
	hero.rotation.y=lerp_angle(hero.rotation.y,heading,minf(1,dt*12))
	hero.position=Ground.point(actor)
	gait_blend=lerpf(gait_blend,1.0 if moving else 0.0,1-exp(-15*dt))
	walk_phase+=minf(motion.length(),SPEED*dt)*PI/.80
	var step_wave:=sin(walk_phase)
	torso.position.y=(.045*absf(step_wave)-.033*pow(absf(cos(walk_phase)),8))*gait_blend
	torso.position.x=.042*step_wave*gait_blend
	torso.rotation.z=.048*step_wave*gait_blend
	torso.rotation.x=.045*gait_blend
	for i in limbs.size():
		var leg_phase:=walk_phase+PI*int(i in [1,2])
		var v:=sin(leg_phase)*(.49 if i<2 else .42)*gait_blend
		if i==3 and swing>0: v=-1.65*sin(PI*swing/.38)
		limbs[i].rotation.x=v
		if i<2: limbs[i].position=foot_positions[i]+Vector3.UP*(.115*maxf(0,-cos(leg_phase))*gait_blend)
	refresh_time-=dt
	if refresh_time<=0:
		refresh_time=.15
		update_ui()

func update_ui() -> void:
	hud.refresh(profile,hp,mp,"Вересковый Град" if town else "Травяной брод")
	hud.gateway.visible=actor.distance_to(Vector2(180,36) if town else START)<6
	hud.gateway.text="К Травяному броду" if town else "В Вересковый Град"
	if hud.sheet.visible:
		hud.sheet.stats={"hp":hp,"mp":mp,"str":profile.strength(),"dex":profile.dexterity()}
		hud.sheet.refresh()
	hud.radar.player=actor
	hud.radar.creatures.clear()
	for mob in mobs:
		if mob.hp>0: hud.radar.creatures.append(mob.flat())
	hud.radar.queue_redraw()
	if town:
		hud.target_name.text="Южные ворота" if actor.y>28 else ("Крепостной двор" if actor.y<-20 else "Рыночный квартал")
	else:
		hud.target_name.text="Выбери Корневика" if target==null else "Корневик · Ур. %d · %d/%d" % [target.rank,target.hp,target.max_hp]
	for i in 7:
		var id: String=profile.hotbar[i]
		var sk: Dictionary=catalog.get(id,{})
		var left:=0.0
		var hint:=""
		if sk.has("index"):
			left=cooldowns[sk.index]
			hint="%d МП" % sk.mp
		elif id=="hit": left=attack_wait
		if left>0: hint="%d с" % ceili(left)
		if pending==id and id!="": hint="Подход"
		hud.slots[i].display(sk,hint,left,true,true,id!="" and id==pending)
