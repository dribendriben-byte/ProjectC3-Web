extends RefCounted

const STEP := 0.5
const LIMIT := Vector2(20,14)
var grid := AStarGrid2D.new()
var blocks: Array = []
var town := false

static func river(z: float) -> float:
	return .105*z+1.15*sin(z*.16)

static func height(p: Vector2) -> float:
	if p.x>100: return .05
	if absf(p.y)<1.27 and absf(p.x)<2.83: return .315
	return .07*sin(p.x*.34)*cos(p.y*.31)+.055*sin(p.y*.62)+.48*clampf((absf(p.y)-7)/7,0,1)+.32*clampf((absf(p.x)-12)/7,0,1)

static func point(p: Vector2) -> Vector3:
	return Vector3(p.x,height(p),p.y)

func _init(city: bool=false) -> void:
	town=city
	var filename := "city_blocks" if city else "obstacles"
	blocks=JSON.parse_string(FileAccess.get_file_as_string("res://ford/models/"+filename+".json"))
	grid.region=Rect2i(268,-78,185,157) if city else Rect2i(-40,-28,81,57)
	grid.cell_size=Vector2.ONE*STEP
	grid.diagonal_mode=AStarGrid2D.DIAGONAL_MODE_ONLY_IF_NO_OBSTACLES
	grid.update()
	if city:
		for b: Array in blocks:
			for x in range(ceili((b[0]-b[2]-.2)/STEP),floori((b[0]+b[2]+.2)/STEP)+1):
				for y in range(ceili((b[1]-b[3]-.2)/STEP),floori((b[1]+b[3]+.2)/STEP)+1):
					var id:=Vector2i(x,y)
					if grid.region.has_point(id): grid.set_point_solid(id,true)
		return
	for x in range(-40,41):
		for y in range(-28,29):
			var id := Vector2i(x,y)
			grid.set_point_solid(id,not legal(Vector2(id)*STEP))

func legal(p: Vector2) -> bool:
	if town:
		if absf(p.x-180)>46 or absf(p.y)>39: return false
	else:
		if absf(p.x)>LIMIT.x or absf(p.y)>LIMIT.y: return false
		if absf(p.x-river(p.y))<2.46 and absf(p.y)>.85: return false
	for b: Array in blocks:
		if absf(b[0]-p.x)<float(b[2])+.20 and absf(b[1]-p.y)<float(b[3])+.20: return false
	return true

func route(a: Vector2,b: Vector2) -> PackedVector2Array:
	var start := Vector2i((a/STEP).round())
	var end := Vector2i((b/STEP).round())
	if not legal(b) or not grid.region.has_point(start) or not grid.region.has_point(end): return []
	# A legal tap near an edge can round onto a blocked cell.
	for is_start in [true,false]:
		var id := start if is_start else end
		if grid.is_point_solid(id):
			var best := INF
			var closest := id
			for dy in range(-1,2):
				for dx in range(-1,2):
					var near := id+Vector2i(dx,dy)
					if grid.region.has_point(near) and not grid.is_point_solid(near):
						var d := (Vector2(near)*STEP).distance_to(a if is_start else b)
						if d<best: best=d; closest=near
			if best==INF: return []
			if is_start: start=closest
			else: end=closest
	var trail := grid.get_point_path(start,end)
	if trail.is_empty(): return []
	if trail.size()>1 and a.distance_to(trail[0])<.09: trail.remove_at(0)
	trail.append(b)
	return trail
