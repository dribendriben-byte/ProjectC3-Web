extends Node2D

const TEXTURES := [preload("res://art/rootling.svg"),preload("res://field/art/wolf.svg"),preload("res://field/art/golem.svg")]
const NAMES := ["Корневик","Вересковый волк","Сланцевик"]
var spoiled := false
var stun := 0.0
var zone := 0
var kind: int
var level: int
var home: Vector2
var hp: int
var max_hp: int
var respawn := 0.0
var attack_timer := 0.0
var phase := 0.0
var engaged := false
var selected := false
var flash := 0.0
var float_text := ""
var float_time := 0.0

func setup(where: Vector2, species: int, rank: int, seed_phase: float) -> void:
	home = where
	position = where
	kind = species
	level = rank
	max_hp = 26 + level*7 + kind*3
	hp = max_hp
	phase = seed_phase

func tick(delta: float, hero_pos: Vector2) -> void:
	if hp <= 0:
		respawn -= delta
		if respawn <= 0:
			hp = max_hp
			spoiled = false
			stun = 0.0
			position = home
			show()
			queue_redraw()
		return
	stun = maxf(0,stun-delta)
	phase += delta
	flash = maxf(0,flash-delta)
	float_time = maxf(0,float_time-delta)
	if engaged:
		attack_timer -= delta
		if stun <= 0 and position.distance_to(hero_pos) > 31:
			position = position.move_toward(hero_pos, (85 + kind*8)*delta)
	else:
		var wander := home + Vector2(cos(phase*.54)*29, sin(phase*.39)*19)
		position = position.move_toward(wander,65*delta)
	if visible and (engaged or selected or float_time > 0):
		queue_redraw()

func disengage() -> void:
	engaged = false
	selected = false
	spoiled = false
	stun = 0
	if hp > 0:
		hp = max_hp
	queue_redraw()

func hurt(amount: int) -> bool:
	hp = maxi(0,hp-amount)
	float_text = "−%d" % amount
	float_time = 0.6
	flash = 0.15
	if hp == 0:
		respawn = 15
		engaged = false
		selected = false
		hide()
	queue_redraw()
	return hp == 0

func _draw() -> void:
	var font := ThemeDB.fallback_font
	draw_set_transform(Vector2.ZERO,0,Vector2(1,.37))
	draw_circle(Vector2.ZERO,22,Color("#26372d85"),true,-1,true)
	if selected:
		draw_arc(Vector2.ZERO,29,0,TAU,42,Color("#ffdf8b"),3,true)
	draw_set_transform(Vector2.ZERO)
	var size_ := [Vector2(50,38),Vector2(54,39),Vector2(47,49)]
	var sz: Vector2 = size_[kind]
	draw_texture_rect(TEXTURES[kind],Rect2(Vector2(-sz.x/2,-sz.y+4),sz),false,Color("#ffc3aa") if flash > 0 else Color.WHITE)
	draw_string_outline(font,Vector2(-29,-sz.y-10),str(level),HORIZONTAL_ALIGNMENT_CENTER,58,12,3,Color("#324033"))
	draw_string(font,Vector2(-29,-sz.y-10),str(level),HORIZONTAL_ALIGNMENT_CENTER,58,12,Color("#fff0c7"))
	if selected or engaged:
		draw_rect(Rect2(-21,-sz.y-7,42,4),Color("#362d31"))
		draw_rect(Rect2(-21,-sz.y-7,42.0*hp/max_hp,4),Color("#f1a47c"))
	if float_time > 0:
		draw_string_outline(font,Vector2(18,-sz.y-9),float_text,HORIZONTAL_ALIGNMENT_LEFT,-1,16,3,Color("#33312d"))
		draw_string(font,Vector2(18,-sz.y-9),float_text,HORIZONTAL_ALIGNMENT_LEFT,-1,16,Color("#fff4cf"))
