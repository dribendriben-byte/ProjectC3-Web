extends Control

var axis := Vector2.ZERO
var owner_id := -1

func reset() -> void:
	owner_id = -1
	axis = Vector2.ZERO
	queue_redraw()

func _set_axis(p: Vector2) -> void:
	axis = ((p-size/2)/40.0).limit_length(1)
	if axis.length() < 0.12:
		axis = Vector2.ZERO
	queue_redraw()

func _gui_input(e: InputEvent) -> void:
	if e is InputEventScreenTouch:
		if e.pressed and owner_id == -1:
			owner_id = e.index
			_set_axis(e.position)
		elif not e.pressed and owner_id == e.index:
			reset()
	elif e is InputEventScreenDrag and e.index == owner_id:
		_set_axis(e.position)
	elif e is InputEventMouseButton and e.device != InputEvent.DEVICE_ID_EMULATION and e.button_index == MOUSE_BUTTON_LEFT:
		if e.pressed:
			owner_id = -2
			_set_axis(e.position)
		elif owner_id == -2:
			reset()
	elif e is InputEventMouseMotion and owner_id == -2:
		_set_axis(e.position)
	accept_event()

func _notification(what: int) -> void:
	if what == NOTIFICATION_APPLICATION_FOCUS_OUT:
		reset()

func _draw() -> void:
	var c := size/2
	draw_circle(c,47,Color("#142520bc"),true,-1,true)
	draw_arc(c,46,0,TAU,72,Color("#c5c8a9"),1.6,true)
	draw_circle(c+axis*27,18,Color("#c0c3a8cf"),true,-1,true)
