extends RefCounted

const BASIC := {
	"hit":{"name":"Атака","effect":"hit","description":"Один удар по выбранной цели. Если нужно, гном подойдёт ближе."},
	"pickup":{"name":"Подобрать","effect":"pickup","description":"Подойти к ближайшей добыче в радиусе 12 м и подобрать её."},
	"cycle":{"name":"Следующая цель","effect":"cycle","description":"Выбрать ближайшего живого моба в радиусе 12 м. Повторный клик переключает цель."}
}

static func build(book: Array[Dictionary]) -> Dictionary:
	var entries := BASIC.duplicate(true)
	for i in book.size():
		var record := book[i].duplicate()
		record["index"]=i
		entries["spell/"+str(record.name)]=record
	return entries

static func initial() -> Array:
	return ["hit","spell/Удар молота","pickup","cycle","","",""]

static func normalize(saved: Variant, entries: Dictionary, hero) -> Array:
	var result := initial()
	if not saved is Array or saved.size()!=7: return result
	result.fill("")
	for i in 7:
		var id: Variant="pickup" if saved[i]=="auto" else saved[i]
		if id is String and entries.has(id) and not result.has(id):
			var rec: Dictionary=entries[id]
			if not rec.has("index") or hero.knows(rec): result[i]=id
	return result
