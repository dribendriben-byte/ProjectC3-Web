extends Button
const Icons=preload("res://field/icon_library.gd")
const EDGE=Color("#a79569")
const GOLD=Color("#f3d18c")
var key_number:=1
var entry: Dictionary={}
var hint:=""
var remaining:=0.0
var armed:=false
var pulse:=0.0

static func bar_rect(index: int) -> Rect2:
	return Rect2(177+index*88,453,78,75)

func setup(number: int) -> void:
	key_number=number
	focus_mode=FOCUS_NONE
	mouse_default_cursor_shape=CURSOR_POINTING_HAND
	flat=true
	mouse_entered.connect(queue_redraw)
	mouse_exited.connect(queue_redraw)
	set_process(false)

func display(sk: Dictionary, detail: String, seconds: float, _known: bool, _ready_now: bool, active: bool) -> void:
	entry=sk
	hint=detail
	remaining=seconds
	armed=active
	tooltip_text=str(sk.get("name","Пустая ячейка"))+"\n"+str(sk.get("description","Назначь действие в книге умений."))
	queue_redraw()

func flash_cast() -> void:
	pulse=1
	set_process(true)

func _process(dt: float) -> void:
	pulse=maxf(0,pulse-dt*4)
	queue_redraw()
	set_process(pulse>0)

static func paint(canvas: Control,r: Rect2,number: int,sk: Dictionary,active: bool,over: bool,seconds: float=0,detail: String="") -> void:
	var font:=ThemeDB.fallback_font
	canvas.draw_rect(r,Color("#142522f2"))
	canvas.draw_rect(r.grow(-2),GOLD if active or over else EDGE,false,2 if active or over else 1)
	if not sk.is_empty():
		var image_r:=Rect2(r.get_center()-Vector2(26,29),Vector2(52,52))
		canvas.draw_texture_rect(Icons.for_skill(sk),image_r,false)
		if seconds>0:
			canvas.draw_rect(Rect2(image_r.position,Vector2(52,52*clampf(seconds/maxf(sk.get("cd",1),.01),0,1))),Color("#0c151ad6"))
		if detail!="": canvas.draw_string(font,r.position+Vector2(2,r.size.y-5),detail,HORIZONTAL_ALIGNMENT_CENTER,r.size.x-4,11,GOLD if active else Color("#d8ddcd"))
	else:
		canvas.draw_string(font,r.position+Vector2(1,44),"◇",HORIZONTAL_ALIGNMENT_CENTER,r.size.x-2,20,Color("#56675c"))
	canvas.draw_string(font,r.position+Vector2(5,15),str(number),HORIZONTAL_ALIGNMENT_LEFT,-1,11,GOLD)
	if active: canvas.draw_rect(Rect2(r.position+Vector2(4,r.size.y-3),Vector2(r.size.x-8,2)),GOLD)

func _draw() -> void:
	paint(self,Rect2(Vector2.ZERO,size),key_number,entry,armed,is_hovered() or is_pressed(),remaining,hint)
	if pulse>0: draw_rect(Rect2(Vector2.ZERO,size),Color(1,.9,.55,.30*pulse))
