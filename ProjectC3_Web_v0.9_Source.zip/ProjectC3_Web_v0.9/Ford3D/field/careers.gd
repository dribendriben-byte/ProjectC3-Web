extends RefCounted

# Race → starting discipline → first profession → advanced professions.
const Experience = preload("res://field/experience.gd")
const Skills = preload("res://field/skills.gd")
const Loot = preload("res://field/loot.gd")
const TREE := {
	"Человек": {
		"Ратник": {"Латник": ["Бастион", "Сумрачный щит"], "Клинок": ["Дуэлянт", "Копейщик"], "Искатель": ["Следопыт", "Стрелок"]},
		"Ученик чар": {"Заклинатель": ["Огневед", "Костепевец", "Зверовод"], "Служитель": ["Целитель", "Провидец"]}},
	"Эльф": {
		"Страж": {"Страж рощи": ["Лунный щит", "Певец клинка"], "Дозорный": ["Лесной охотник", "Лунный лучник"]},
		"Ученик росы": {"Чародей росы": ["Ледяной голос", "Хозяин ручья"], "Оракул рощи": ["Хранитель росы"]}},
	"Тёмный эльф": {
		"Воин тени": {"Страж пепла": ["Рыцарь затмения", "Танцор стали"], "Ловчий": ["Тень ущелья", "Сумрачный лучник"]},
		"Ученик сумерек": {"Чародей мглы": ["Глас бури", "Призыватель мглы"], "Оракул ночи": ["Хранитель сумерек"]}},
	"Орк": {
		"Боец": {"Налётчик": ["Сокрушитель"], "Боец круга": ["Костолом"]},
		"Ученик духов": {"Шаман": ["Вождь духов", "Глашатай"]}},
	"Гном": {
		"Подгорный боец": {"Сборщик": ["Искатель жил"], "Мастеровой": ["Рунный кузнец"]}}
}
const SKINS := [
	[preload("res://field/art/human.svg"),preload("res://field/art/human_mage.svg")],
	[preload("res://field/art/elf.svg"),preload("res://field/art/elf_mage.svg")],
	[preload("res://field/art/dark.svg"),preload("res://field/art/dark_mage.svg")],
	[preload("res://field/art/orc.svg"),preload("res://field/art/orc_mage.svg")],
	[preload("res://field/art/dwarf.svg")]
]
# hp, damage, movement speed adjustment
const BONUSES := {
	"Человек": [6,1,0], "Эльф": [0,0,20], "Тёмный эльф": [0,2,5],
	"Орк": [12,2,-9], "Гном": [16,0,-5]
}
func save_path() -> String:
	return legacy_path().replace(".cfg","_v5.cfg")

func legacy_path() -> String:
	return "user://frontier_%d_%d.cfg" % [TREE.keys().find(race),TREE[race].keys().find(origin)]

var race := ""
var origin := ""
var first := ""
var second := ""
var total_xp := 1
var kills := 0
var sp := 0
var learned := {}
var adena := 0
var inventory := {}
var equipment := {}
var hotbar: Array = []
var muted := false
var ground_loot: Array = []

func level() -> int:
	return Experience.level_of(total_xp)

func title() -> String:
	if not second.is_empty():
		return second
	return first if not first.is_empty() else origin

func mystic() -> bool:
	return TREE[race].keys().find(origin) == 1

func hp_max() -> int:
	return 42 + int(BONUSES[race][0]) + (level()-1)*5 + (8 if first != "" else 0)

func strength() -> int:
	return 6+level()*2+int(BONUSES[race][1])

func dexterity() -> int:
	return 10+int(BONUSES[race][2])

func damage() -> int:
	return equipped_bonus("Оружие") + strength() + role_score("Оружейник")*2 + (4 if first != "" else 0) + (8 if second != "" else 0)

func choices() -> Array:
	if first == "" and level() >= 20:
		return TREE[race][origin].keys()
	if first != "" and second == "" and level() >= 40:
		return TREE[race][origin][first]
	return []

func promote(choice: String) -> bool:
	if not choices().has(choice):
		return false
	if first.is_empty():
		first = choice
	else:
		second = choice
	return true

func mana_max() -> int:
	return (40 if mystic() else 26) + level()*2

func defense() -> int:
	return role_score("Щит")*3 + equipped_bonus("Грудь") + equipped_bonus("Запястья")

func equipped_bonus(slot: String) -> int:
	var id: String = equipment.get(slot,"")
	return int(Loot.ITEMS[id][2]) if Loot.ITEMS.has(id) else 0

func toggle_item(id: String) -> bool:
	if not Loot.ITEMS.has(id) or inventory.get(id,0)<1:
		return false
	var slot: String = Loot.ITEMS[id][1]
	if slot == "Материал":
		return false
	if equipment.get(slot,"")==id:
		equipment.erase(slot)
	else:
		equipment[slot]=id
	return true

func knows(sk: Dictionary) -> bool:
	return sk.level==1 or learned.has(sk.name)

func learn(sk: Dictionary) -> bool:
	if knows(sk) or level()<sk.level or sp<sk.sp or not Skills.book(self).has(sk):
		return false
	sp -= int(sk.sp)
	learned[sk.name] = true
	return true

func earn(xp: int) -> void:
	total_xp = mini(Experience.START.back(),total_xp+xp)
	kills += 1
	sp += maxi(1,roundi(xp*.06))

func collect(reward: Dictionary) -> void:
	adena += int(reward.adena)
	for item in reward.items:
		inventory[item] = int(inventory.get(item,0))+int(reward.items[item])

func store_character() -> Error:
	var file := ConfigFile.new()
	file.set_value("hero","version",5)
	for key in ["race","origin","first","second","total_xp","kills","adena","inventory","equipment","sp","learned","hotbar","muted","ground_loot"]:
		file.set_value("hero", key, get(key))
	var err := file.save(save_path() + ".tmp")
	if err != OK:
		return err
	err = DirAccess.rename_absolute(ProjectSettings.globalize_path(save_path() + ".tmp"), ProjectSettings.globalize_path(save_path()))
	if err == OK and OS.has_feature("web"):
		JavaScriptBridge.force_fs_sync()
	return err

func restore() -> bool:
	var file := ConfigFile.new()
	var path := save_path() if FileAccess.file_exists(save_path()) else legacy_path()
	if file.load(path) != OK:
		return false
	var r = file.get_value("hero","race","")
	var o = file.get_value("hero","origin","")
	if r != race or o != origin:
		return false
	var f = file.get_value("hero","first","")
	var s = file.get_value("hero","second","")
	var branches: Dictionary = TREE[r][o]
	if f != "" and not branches.has(f):
		return false
	if s != "" and (f == "" or not branches[f].has(s)):
		return false
	race = r
	origin = o
	first = f
	second = s
	total_xp = maxi(0, int(file.get_value("hero","total_xp",0)))
	kills = maxi(0, int(file.get_value("hero","kills",0)))
	if file.get_value("hero","version",4) < 5:
		total_xp = Experience.migrate(total_xp)
		inventory = {}
		for sk in Skills.book(self):
			if level()>=sk.level: learned[sk.name]=true
		var old_bark := maxi(0,int(file.get_value("hero","bark",0)))
		if old_bark > 0:
			inventory["bark"] = old_bark
	else:
		total_xp = mini(total_xp,Experience.START.back())
		sp = maxi(0,int(file.get_value("hero","sp",0)))
		learned = file.get_value("hero","learned",{})
		adena = maxi(0,int(file.get_value("hero","adena",0)))
		inventory = file.get_value("hero","inventory",{})
		equipment = file.get_value("hero","equipment",{})
		if equipment.get("Броня","")=="bracer":
			equipment["Запястья"]="bracer"
			equipment.erase("Броня")
		ground_loot=file.get_value("hero","ground_loot",[])
		var stored = file.get_value("hero","hotbar",[])
		hotbar = stored if stored is Array else []
		muted = bool(file.get_value("hero","muted",false))
	return true

# Each promotion inherits its preceding role. The advanced role refines it.
const ROLES := {
	"Щит": ["Латник","Бастион","Сумрачный щит","Страж рощи","Лунный щит","Страж пепла","Рыцарь затмения","Вождь духов"],
	"Дальний бой": ["Стрелок","Дозорный","Лунный лучник","Ловчий","Сумрачный лучник"],
	"Натиск": ["Клинок","Дуэлянт","Копейщик","Певец клинка","Танцор стали","Налётчик","Сокрушитель","Боец круга","Костолом","Заклинатель","Огневед","Чародей росы","Ледяной голос","Чародей мглы","Глас бури"],
	"Восстановление": ["Служитель","Целитель","Провидец","Оракул рощи","Хранитель росы","Оракул ночи","Хранитель сумерек","Шаман","Глашатай","Костепевец","Зверовод","Хозяин ручья","Призыватель мглы"],
	"Добыча": ["Искатель","Следопыт","Лесной охотник","Тень ущелья","Сборщик","Искатель жил"],
	"Оружейник": ["Мастеровой","Рунный кузнец"]
}

func role_score(role: String) -> int:
	var values: Array = ROLES[role]
	return int(values.has(first)) + int(values.has(second))

func attack_range() -> float:
	return (155.0 if mystic() else 43.0) + role_score("Дальний бой") * 75.0
