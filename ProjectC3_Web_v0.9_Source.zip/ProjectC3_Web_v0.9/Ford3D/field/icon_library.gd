extends RefCounted

const TEXTURES := {
	"pickup":preload("res://field/art/icons/pickup.svg"),
	"branch":preload("res://field/art/icons/branch.svg"),
	"cuirass":preload("res://field/art/icons/cuirass.svg"),

	"bag": preload("res://field/art/icons/bag.svg"),
	"book": preload("res://field/art/icons/book.svg"),
	"person": preload("res://field/art/icons/person.svg"),
	"career": preload("res://field/art/icons/career.svg"),
	"hit": preload("res://field/art/icons/hit.svg"),
	"cycle": preload("res://field/art/icons/cycle.svg"),
	"sound": preload("res://field/art/icons/sound.svg"),
	"mute": preload("res://field/art/icons/mute.svg"),

	"ember": preload("res://field/art/icons/ember.svg"),
	"frost": preload("res://field/art/icons/frost.svg"),
	"fist": preload("res://field/art/icons/fist.svg"),
	"roots": preload("res://field/art/icons/roots.svg"),
	"moon": preload("res://field/art/icons/moon.svg"),
	"storm": preload("res://field/art/icons/storm.svg"),

	"adena": preload("res://field/art/icons/adena.svg"),
	"bark": preload("res://field/art/icons/bark.svg"),
	"bracer": preload("res://field/art/icons/bracer.svg"),
	"crush": preload("res://field/art/icons/crush.svg"),
	"drain": preload("res://field/art/icons/drain.svg"),
	"fang": preload("res://field/art/icons/fang.svg"),
	"focus": preload("res://field/art/icons/focus.svg"),
	"guard": preload("res://field/art/icons/guard.svg"),
	"hammer": preload("res://field/art/icons/hammer.svg"),
	"haste": preload("res://field/art/icons/haste.svg"),
	"heal": preload("res://field/art/icons/heal.svg"),
	"knife": preload("res://field/art/icons/knife.svg"),
	"locked": preload("res://field/art/icons/locked.svg"),
	"ranged": preload("res://field/art/icons/ranged.svg"),
	"renew": preload("res://field/art/icons/renew.svg"),
	"slate": preload("res://field/art/icons/slate.svg"),
	"spoil": preload("res://field/art/icons/spoil.svg"),
	"strike": preload("res://field/art/icons/strike.svg"),
	"stun": preload("res://field/art/icons/stun.svg"),
}

static func get_icon(id: String) -> Texture2D:
	return TEXTURES.get(id,TEXTURES.locked)

const SPECIAL := {
	"Удар молота":"hammer", "Удар наковальни":"hammer", "Клёпка":"hammer",
	"Рудный раскол":"crush", "Гул породы":"slate", "Удар щитом":"guard",
	"Бросок ножа":"knife", "Удар кулака":"fist", "Серия ударов":"fist", "Ладонь грома":"storm",
	"Дух углей":"ember", "Искра":"ember", "Огненная стрела":"ember", "Метеор":"ember",
	"Капля льда":"frost", "Игла льда":"frost", "Ледяные путы":"frost", "Ледопад":"frost", "Ледяной плен":"frost",
	"Корни":"roots", "Кора дуба":"roots", "Щит листвы":"roots",
	"Сумрак":"moon", "Лунный покров":"moon", "Ночная медитация":"moon",
	"Порыв бури":"storm", "Гром":"storm"
}

static func for_skill(skill: Dictionary) -> Texture2D:
	return get_icon(SPECIAL.get(skill.get("name",""),skill.get("effect","locked")))
