extends RefCounted

# Each step supplies a distinct action. Mechanics, costs and cooldowns are in TYPES.
const TYPES := {
	"strike":[5,4.0,"Усиленная атака выбранной цели."],
	"ranged":[6,5.0,"Атака с расстояния до 220."],
	"stun":[7,8.0,"Удар и оглушение цели на 2 с."],
	"drain":[8,7.0,"Удар возвращает часть нанесённого урона в виде ОЗ."],
	"heal":[8,9.0,"Восстанавливает до 30% максимального здоровья."],
	"guard":[5,12.0,"На 7 с уменьшает входящий урон вдвое."],
	"haste":[5,12.0,"На 7 с повышает скорость бега и автоатак."],
	"focus":[4,12.0,"На 8 с повышает урон автоатаки на 40%."],
	"spoil":[6,7.0,"Помечает живую цель. Победа даёт дополнительный ресурс."],
	"crush":[10,7.0,"Мощная атака с тройным уроном."],
	"renew":[0,20.0,"Восстанавливает 25% максимальной маны."]
}
# label/effect pairs in learning order; each row refers to one starting class or first profession.
const BASE := {
	"Ратник":["Рубящий удар/strike","Таран/stun","Стойка щита/guard","Боевой клич/focus"],
	"Ученик чар":["Искра/ranged","Первая помощь/heal","Отток/drain","Ясность/renew"],
	"Страж":["Выпад/strike","Лесная стрела/ranged","Лёгкий шаг/haste","Кора дуба/guard"],
	"Ученик росы":["Капля льда/ranged","Роса жизни/heal","Ледяные путы/stun","Тихий ручей/renew"],
	"Воин тени":["Тёмный выпад/strike","Бросок ножа/ranged","Шаг тени/haste","Кража сил/drain"],
	"Ученик сумерек":["Сумрак/ranged","Вампиризм/drain","Печать тени/stun","Ночная медитация/renew"],
	"Боец":["Удар кулака/strike","Рёв/focus","Каменная кожа/guard","Сотрясение/stun"],
	"Ученик духов":["Дух углей/ranged","Круг предков/heal","Сила тотема/focus","Транс/renew"],
	"Подгорный боец":["Удар молота/strike","Закалка/guard","Спойл/spoil","Гул породы/stun"]
}
const FIRST := {
	"Латник":["Удар щитом/stun","Бастион/guard","Приговор/crush"],
	"Клинок":["Раскол/crush","Ритм битвы/haste","Решимость/focus"],
	"Искатель":["Меткий выстрел/ranged","Скачок/haste","Удар в брешь/crush"],
	"Заклинатель":["Огненная стрела/ranged","Ожог души/drain","Метеор/crush"],
	"Служитель":["Молитва/heal","Оберег/guard","Созерцание/renew"],
	"Страж рощи":["Корни/stun","Щит листвы/guard","Живица/heal"],
	"Дозорный":["Выстрел дозора/ranged","Попутный ветер/haste","Пробой/crush"],
	"Чародей росы":["Игла льда/ranged","Ледяной плен/stun","Ледопад/crush"],
	"Оракул рощи":["Свет рощи/heal","Песнь ветра/haste","Поток/renew"],
	"Страж пепла":["Пепельный щит/guard","Кровавый клинок/drain","Клеймо/stun"],
	"Ловчий":["Чёрная стрела/ranged","Охотничий азарт/focus","Засада/crush"],
	"Чародей мглы":["Порыв бури/ranged","Глоток тьмы/drain","Гром/crush"],
	"Оракул ночи":["Ночная роса/heal","Лунный покров/guard","Тёмный родник/renew"],
	"Налётчик":["Пролом/crush","Ярость/focus","Тяжёлая поступь/stun"],
	"Боец круга":["Серия ударов/crush","Тотем рыси/haste","Ладонь грома/stun"],
	"Шаман":["Зов духов/drain","Песнь крови/heal","Ритуал силы/focus"],
	"Сборщик":["Проба жилы/spoil","Рудный раскол/crush","Хватка старателя/stun"],
	"Мастеровой":["Клёпка/stun","Панцирь кузни/guard","Удар наковальни/crush"]
}

static func book(hero) -> Array[Dictionary]:
	var list: Array[Dictionary] = []
	var steps := [1,7,14,18] if hero.mystic() else [1,5,10,15]
	_append(list,BASE[hero.origin],steps)
	if FIRST.has(hero.first):
		_append(list,FIRST[hero.first],[20,28,36])
	return list

static func _append(list: Array[Dictionary], entries: Array, steps: Array) -> void:
	for i in entries.size():
		var pair: PackedStringArray = entries[i].split("/")
		var params: Array = TYPES[pair[1]]
		list.append({"sp":sp_cost(steps[i]),"name":pair[0],"effect":pair[1],"level":steps[i],"mp":params[0],"cd":params[1],"description":params[2]})

static func sp_cost(lv: int) -> int:
	match lv:
		1: return 0
		5: return 50
		7: return 100
		10: return 250
		14,15: return 650
		18: return 1200
		20: return 1600
		28: return 4500
		_: return 10000

static func offensive(effect: String) -> bool:
	return effect in ["strike","ranged","crush","drain","stun","spoil"]
