extends Control
signal closed
signal equip(id: String)
const Loot=preload("res://field/loot.gd")
const Icons=preload("res://field/icon_library.gd")
const Dress=preload("res://ford/worn.gd")
const PAPER=Color("#f0ead8")
const GOLD=Color("#dfc18c")
const SOFT=Color("#acbdaf")
const SLOTS:=["Голова","Грудь","Запястья","Ноги","Оружие","Щит","Кольцо","Спина"]
# Equipment silhouettes, in a 24-pixel square.
const SHAPES:=[
	[Vector2(3,18),Vector2(3,10),Vector2(7,4),Vector2(15,3),Vector2(20,9),Vector2(21,18),Vector2(17,18),Vector2(16,12),Vector2(13,13),Vector2(12,20),Vector2(10,13),Vector2(6,11),Vector2(6,18)],
	[Vector2(2,6),Vector2(8,3),Vector2(12,6),Vector2(16,3),Vector2(22,6),Vector2(19,12),Vector2(17,11),Vector2(17,21),Vector2(7,21),Vector2(7,11),Vector2(5,12)],
	[Vector2(3,5),Vector2(14,3),Vector2(21,18),Vector2(10,21)],
	[Vector2(7,3),Vector2(17,3),Vector2(16,13),Vector2(20,16),Vector2(21,20),Vector2(5,20),Vector2(5,16),Vector2(8,13)],
	[Vector2(3,20),Vector2(8,14),Vector2(5,11),Vector2(7,9),Vector2(10,12),Vector2(17,4),Vector2(22,2),Vector2(20,8),Vector2(12,14),Vector2(15,17),Vector2(13,19),Vector2(10,16),Vector2(5,22)],
	[Vector2(3,5),Vector2(12,2),Vector2(21,5),Vector2(20,12),Vector2(17,17),Vector2(12,21),Vector2(7,17),Vector2(4,12)],
	[Vector2(8,8),Vector2(7,5),Vector2(10,2),Vector2(14,2),Vector2(17,5),Vector2(16,8),Vector2(19,12),Vector2(19,16),Vector2(16,20),Vector2(9,21),Vector2(5,17),Vector2(5,12)],
	[Vector2(8,3),Vector2(16,3),Vector2(18,7),Vector2(20,17),Vector2(22,20),Vector2(15,19),Vector2(10,21),Vector2(2,19),Vector2(5,14),Vector2(6,7)]
]
var hero
var sheet:=false
var chosen:=""
var filter:=0
var selected_slot:=""
var pointer:=-99
var dragging:=false
var start:=Vector2.ZERO
var offset:=Vector2.ZERO
var portrait:SubViewportContainer
var viewport3:SubViewport
var figure:Node3D
var stats:={}
var drag_item:=""
var drag_point:=Vector2.ZERO
var peer:Control

func init(as_sheet: bool) -> void:
	sheet=as_sheet
	size=Vector2(360,423) if sheet else Vector2(386,403)
	mouse_filter=MOUSE_FILTER_STOP
	hide()
	if sheet: build_portrait()

func build_portrait() -> void:
	portrait=SubViewportContainer.new()
	portrait.position=Vector2(94,64)
	portrait.size=Vector2(172,191)
	portrait.mouse_filter=MOUSE_FILTER_IGNORE
	portrait.stretch=true
	add_child(portrait)
	viewport3=SubViewport.new()
	viewport3.size=Vector2i(172,191)
	viewport3.own_world_3d=true
	viewport3.transparent_bg=true
	portrait.add_child(viewport3)
	figure=preload("res://ford/models/warden.glb").instantiate()
	viewport3.add_child(figure)
	figure.rotation.y=.29
	var cam:=Camera3D.new()
	viewport3.add_child(cam)
	cam.projection=Camera3D.PROJECTION_ORTHOGONAL
	cam.size=2.38
	cam.position=Vector3(0,1.38,4.2)
	cam.look_at(Vector3(0,1.03,0))
	var env:=Environment.new()
	env.ambient_light_source=Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color=Color("#f3ebce")
	env.ambient_light_energy=.86
	cam.environment=env
	var sun:=DirectionalLight3D.new()
	viewport3.add_child(sun)
	sun.rotation_degrees=Vector3(-38,156,0)
	sun.light_energy=1.05

func present(value) -> void:
	hero=value
	show()
	raise_panel()
	refresh(true)

func raise_panel() -> void:
	get_parent().move_child(self,-1)

func refresh(gear_changed:=false) -> void:
	if hero==null: return
	if sheet and gear_changed:
		Dress.fit(figure,hero.equipment)
		viewport3.render_target_update_mode=SubViewport.UPDATE_ONCE
	if not sheet and not ids().has(chosen):
		var available:=ids()
		chosen="" if available.is_empty() else available[0]
	queue_redraw()

func ids() -> Array:
	var list: Array=[]
	for id in Loot.ITEMS:
		if hero.inventory.get(id,0)<=0: continue
		var material:bool=Loot.ITEMS[id][1]=="Материал"
		if (filter==1 and material) or (filter==2 and not material): continue
		list.append(id)
	return list

func cell(i: int) -> Rect2:
	return Rect2(16+(i%5)*71,113+floori(i/5.0)*65,65,59)

func gear_cell(i: int) -> Rect2:
	return Rect2(13 if i<4 else 274,63+(i%4)*49,73,45)

func box(r: Rect2,fill: Color,edge: Color) -> void:
	draw_rect(r,fill)
	draw_rect(r.grow(-1),edge,false,1)

func line(p: Vector2,t: String,px:=15,c:=PAPER,w:float=-1,a:=HORIZONTAL_ALIGNMENT_LEFT) -> void:
	draw_string(ThemeDB.fallback_font,p,t,a,w,px,c)

func pic(id: String,r: Rect2) -> void:
	draw_texture_rect(Icons.get_icon(id),r,false)

func _draw() -> void:
	if hero==null: return
	box(Rect2(Vector2.ZERO,size),Color("#172a28"),Color("#b29b71"))
	draw_rect(Rect2(3,3,size.x-6,39),Color("#2b4540"))
	line(Vector2(14,28),"Персонаж" if sheet else "Инвентарь",21,GOLD)
	for i in 3: draw_line(Vector2(size.x*.53-10,17+i*4),Vector2(size.x*.53+10,17+i*4),Color("#79877b"),1)
	line(Vector2(size.x-38,30),"×",24,GOLD,28,HORIZONTAL_ALIGNMENT_CENTER)
	if sheet: draw_sheet()
	else:
		draw_bag()
		if drag_item!="" and (position+drag_point).distance_to(start)>=8:
			var ghost:=Rect2(drag_point-Vector2(18,40),Vector2(38,38))
			box(ghost,Color("#283e34"),GOLD)
			pic(drag_item,ghost.grow(-2))

func draw_sheet() -> void:
	box(Rect2(93,61,174,197),Color("#314640"),Color("#69785d"))
	draw_circle(Vector2(180,155),74,Color("#394f46"))
	for i in 2:
		draw_arc(Vector2(180,154),65+i*6,0,TAU,80,Color("#66745c"),1,true)
	for i in 8:
		var sl: String=SLOTS[i]
		var r:=gear_cell(i)
		var id: String=hero.equipment.get(sl,"")
		box(r,Color("#243a34"),GOLD if selected_slot==sl else Color("#596a57"))
		if id!="": pic(id,Rect2(r.position+Vector2(24,2),Vector2(26,26)))
		else:
			var outline:=PackedVector2Array()
			for pt in SHAPES[i]: outline.append(r.position+Vector2(25,2)+pt)
			draw_colored_polygon(outline,Color("#394e42"))
			outline.append(outline[0])
			draw_polyline(outline,Color("#99a48a"),1.15,true)
			if i==6: draw_arc(r.position+Vector2(37,16),4,0,TAU,18,Color("#99a48a"),1,true)
		line(r.position+Vector2(1,39),sl,11,SOFT,r.size.x-2,HORIZONTAL_ALIGNMENT_CENTER)
	line(Vector2(13,284),"%s · Ур. %d" % [hero.title(),hero.level()],17,GOLD)
	var rows: Array=[["Сила",stats.get("str",0),"Атака",hero.damage()],["Ловкость",stats.get("dex",0),"Защита",hero.defense()],["Здоровье","%d/%d" % [stats.get("hp",0),hero.hp_max()],"Мана","%d/%d" % [stats.get("mp",0),hero.mana_max()]],["Опыт",hero.total_xp,"SP",hero.sp]]
	for i in rows.size():
		var y:=296+i*24
		draw_line(Vector2(14,y),Vector2(346,y),Color("#42564b"))
		for j in 2:
			line(Vector2(14+j*175,y+18),str(rows[i][j*2]),13,SOFT)
			line(Vector2(88+j*175,y+18),str(rows[i][j*2+1]),14,PAPER,78,HORIZONTAL_ALIGNMENT_RIGHT)
	var item: String=hero.equipment.get(selected_slot,"")
	line(Vector2(14,411),("Снять · "+str(Loot.ITEMS[item][0])) if item!="" else "Выбери ячейку снаряжения",13,GOLD if item!="" else SOFT)

func draw_bag() -> void:
	pic("adena",Rect2(17,49,24,24))
	line(Vector2(49,67),"Адена  %d" % hero.adena,16,GOLD)
	for i in 3:
		var r:=Rect2(16+i*118,78,113,28)
		box(r,Color("#344e40") if i==filter else Color("#213732"),GOLD if i==filter else Color("#536653"))
		line(r.position+Vector2(0,20),["Всё","Экипировка","Материалы"][i],13,PAPER,113,HORIZONTAL_ALIGNMENT_CENTER)
	var list:=ids()
	for i in 10:
		var r:=cell(i)
		var id: String=list[i] if i<list.size() else ""
		box(r,Color("#2d4539") if id!="" else Color("#1e332d"),GOLD if id!="" and chosen==id else Color("#4d604f"))
		if id=="": continue
		pic(id,Rect2(r.position+Vector2(9,2),Vector2(46,46)))
		line(r.position+Vector2(0,54),"×%d" % hero.inventory[id],12,PAPER,61,HORIZONTAL_ALIGNMENT_RIGHT)
		if hero.equipment.values().has(id): line(r.position+Vector2(3,14),"◆",11,GOLD)
	draw_line(Vector2(16,247),Vector2(367,247),GOLD)
	if chosen=="":
		line(Vector2(22,287),"В этой вкладке пока пусто",17,PAPER)
		return
	var info: Array=Loot.ITEMS[chosen]
	pic(chosen,Rect2(17,260,70,70))
	line(Vector2(101,281),info[0],19,PAPER)
	line(Vector2(101,305),info[1],14,GOLD)
	var chance := {"cuirass":"Корневик · 3%","branch":"Корневик · 33%","bark":"Корневик · %d%%" % roundi(34+4*hero.role_score("Добыча")),"bracer":"Корневик · 2,5%","slate":"Сланцевик · 42%","fang":"Вересковый волк · 27%","knife":"Вересковый волк · 1,8%","hammer":"Сланцевик · 1,2%"}
	line(Vector2(101,326),chance[chosen],13,SOFT)
	if info[1]=="Материал":
		line(Vector2(20,374),"В сумке  ×%d" % hero.inventory[chosen],16,GOLD)
		return
	var worn:bool=hero.equipment.get(info[1],"")==chosen
	var weapon:bool=info[1]=="Оружие"
	var cur:int=hero.damage() if weapon else hero.defense()
	var diff:int=-info[2] if worn else info[2]-hero.equipped_bonus(info[1])
	line(Vector2(17,374),"%s  %d → %d" % ["Атака" if weapon else "Защита",cur,cur+diff],16,GOLD)
	box(Rect2(209,345,158,42),Color("#415746"),GOLD)
	line(Vector2(211,372),"Снять" if worn else "Надеть",16,PAPER,154,HORIZONTAL_ALIGNMENT_CENTER)

func _gui_input(e: InputEvent) -> void:
	var id: int
	if e is InputEventScreenTouch or e is InputEventScreenDrag: id=e.index
	elif e is InputEventMouseButton or e is InputEventMouseMotion:
		if e.device==InputEvent.DEVICE_ID_EMULATION: return
		if e is InputEventMouseButton and e.button_index!=MOUSE_BUTTON_LEFT: return
		id=-1
	else: return
	var p:Vector2=e.position
	var world:=position+p
	if e is InputEventScreenTouch or e is InputEventMouseButton:
		if e.pressed and pointer==-99:
			raise_panel()
			pointer=id
			start=world
			drag_point=p
			offset=p
			dragging=p.y<42 and p.x<size.x-47
			if not sheet:
				var list:=ids()
				for i in list.size():
					if cell(i).has_point(p): drag_item=list[i]
		elif not e.pressed and pointer==id:
			if not e.canceled:
				if not dragging and start.distance_to(world)<8: activate(p)
				elif drag_item!="" and peer.visible and peer.get_rect().has_point(world):
					var slot:String=Loot.ITEMS[drag_item][1]
					if slot!="Материал" and hero.equipment.get(slot,"")!=drag_item:
						for i in 8:
							if SLOTS[i]==slot and peer.gear_cell(i).has_point(world-peer.position): equip.emit(drag_item)
			pointer=-99
			dragging=false
			drag_item=""
			queue_redraw()
	elif pointer==id:
		if dragging: position=(world-offset).clamp(Vector2.ZERO,Vector2(960,540)-size)
		elif drag_item!="":
			drag_point=p
			queue_redraw()
	accept_event()

func activate(p: Vector2) -> void:
	if p.y<42 and p.x>size.x-47: hide(); closed.emit(); return
	if sheet:
		for i in 8:
			if gear_cell(i).has_point(p): selected_slot=SLOTS[i]
		if p.y>=394 and hero.equipment.has(selected_slot): equip.emit(hero.equipment[selected_slot])
	else:
		var available:=ids()
		for i in 3:
			if Rect2(16+i*118,77,113,31).has_point(p):
				filter=i
				refresh()
				return
		for i in available.size():
			if cell(i).has_point(p): chosen=available[i]
		if Rect2(209,345,158,42).has_point(p) and chosen!="" and Loot.ITEMS[chosen][1]!="Материал": equip.emit(chosen)
	queue_redraw()

func _notification(what: int) -> void:
	if what==NOTIFICATION_VISIBILITY_CHANGED or what==NOTIFICATION_APPLICATION_FOCUS_OUT:
		pointer=-99
		dragging=false
		drag_item=""
