extends RefCounted

const ITEMS := {
	"branch":["Веточка", "Материал",0], "cuirass":["Деревянный нагрудник","Грудь",5],
	"bark":["Пластина коры","Материал",0], "fang":["Клык волка","Материал",0],
	"slate":["Сланцевая руда","Материал",0], "bracer":["Наручи из коры","Запястья",3],
	"knife":["Клык-клинок","Оружие",4], "hammer":["Сланцевый молот","Оружие",7]
}
# resource, gear, independent chances, guaranteed adena range per level.
const TABLE := [
	["bark","bracer",0.34,0.025,4,8],
	["fang","knife",0.27,0.018,6,11],
	["slate","hammer",0.42,0.012,8,14]
]

static func roll(kind: int, rank: int, harvest_bonus: float, spoiled: bool, rng: RandomNumberGenerator) -> Dictionary:
	var t: Array = TABLE[kind]
	var bag := {}
	if rng.randf()<t[2]+harvest_bonus:
		bag[t[0]] = 1
	if spoiled:
		bag[t[0]] = bag.get(t[0],0)+1
	if rng.randf()<t[3]:
		bag[t[1]] = 1
	if kind==0:
		if rng.randf()<.33: bag["branch"]=1
		if rng.randf()<.03: bag["cuirass"]=1
	return {"adena":rng.randi_range(t[4]*rank,t[5]*rank),"items":bag}

static func xp_for(kind: int, rank: int, hero_level: int) -> int:
	var base := 29*rank + floori([0.5,0.16,1.54][kind]*rank*rank)
	var factor := clampf(1.0-maxi(0,hero_level-rank-5)*0.1,0.1,1.0)
	return maxi(1,roundi(base*factor))
