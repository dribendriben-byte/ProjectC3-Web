extends Control
signal closed
signal changed
signal learn_requested(index: int)
const Slot=preload("res://field/skill_button.gd")
const Icons=preload("res://field/icon_library.gd")
const INK=Color("#162922")
const GOLD=Color("#edcb91")
const PAPER=Color("#f2ecd8")
const MUTED=Color("#aabbab")
const CLOSE:=Rect2(844,28,75,40)
const ACTION:=Rect2(713,338,194,44)
var hero
var catalog: Dictionary
var chosen:=""
var pressed_id:=""
var pressed_slot:=-1
var click_control:=""
var pointer:=-99
var origin:=Vector2.ZERO
var current:=Vector2.ZERO
var dragging:=false
var status:=""

func present(profile, entries: Dictionary) -> void:
	hero=profile
	catalog=entries
	chosen=""
	status=""
	reset_pointer()
	show()
	queue_redraw()

func reset_pointer() -> void:
	pressed_id=""
	pressed_slot=-1
	click_control=""
	dragging=false
	pointer=-99

func allowed(id: String) -> bool:
	return catalog.has(id) and (not catalog[id].has("index") or hero.knows(catalog[id]))

func card_rect(i: int) -> Rect2:
	return Rect2(49+(i%5)*174,106+floori(i/5.0)*101,163,91)

func slot_at(p: Vector2) -> int:
	for i in 7:
		if Slot.bar_rect(i).has_point(p): return i
	return -1

func card_at(p: Vector2) -> String:
	var ids:=catalog.keys()
	for i in ids.size():
		if card_rect(i).has_point(p): return ids[i]
	return ""

func _gui_input(e: InputEvent) -> void:
	var id: int
	if e is InputEventScreenTouch or e is InputEventScreenDrag: id=e.index
	elif e is InputEventMouseButton or e is InputEventMouseMotion:
		if e.device==InputEvent.DEVICE_ID_EMULATION: return
		id=-1
	else: return
	if e is InputEventMouseButton and e.button_index!=MOUSE_BUTTON_LEFT: return
	var p: Vector2=e.position
	if e is InputEventMouseButton or e is InputEventScreenTouch:
		if e.pressed and pointer==-99:
			pointer=id
			origin=p
			current=p
			pressed_slot=slot_at(p)
			pressed_id=card_at(p) if pressed_slot<0 else str(hero.hotbar[pressed_slot])
			if CLOSE.has_point(p): click_control="close"
			elif ACTION.has_point(p): click_control="action"
		elif not e.pressed and pointer==id:
			if not e.canceled: finish(p)
			reset_pointer()
	elif pointer==id:
		current=p
		dragging=allowed(pressed_id) and origin.distance_to(p)>8
	queue_redraw()
	accept_event()

func finish(p: Vector2) -> void:
	if click_control=="close" and CLOSE.has_point(p):
		closed.emit()
		return
	if click_control=="action" and ACTION.has_point(p):
		if chosen.is_empty(): return
		var rec: Dictionary=catalog[chosen]
		if allowed(chosen):
			var ix: int=hero.hotbar.find(chosen)
			if ix>=0:
				hero.hotbar[ix]=""
				changed.emit()
				status="Ячейка %d освобождена." % (ix+1)
		elif hero.level()>=rec.level and hero.sp>=rec.sp:
			learn_requested.emit(rec.index)
		return
	var to:=slot_at(p)
	if dragging or (allowed(pressed_id) and origin.distance_to(p)>8):
		if to>=0: assign(pressed_id,to)
		return
	if origin.distance_to(p)>8: return
	if pressed_slot>=0 and to==pressed_slot:
		if allowed(chosen): assign(chosen,to)
		elif not pressed_id.is_empty(): chosen=pressed_id
	elif pressed_id!="" and card_at(p)==pressed_id:
		chosen=pressed_id
		status=""

func assign(id: String,to: int) -> void:
	if not allowed(id): return
	var old: int=hero.hotbar.find(id)
	if old>=0: hero.hotbar[old]=hero.hotbar[to]
	hero.hotbar[to]=id
	chosen=""
	status="%s → ячейка %d" % [catalog[id].name,to+1]
	changed.emit()

func box(r: Rect2,bg: Color,edge: Color,thick:=1) -> void:
	draw_rect(r,bg)
	draw_rect(r.grow(-1),edge,false,thick)

func words(p: Vector2,t: String,px: int,tint: Color,span: float=-1,align:=HORIZONTAL_ALIGNMENT_LEFT) -> void:
	draw_string(ThemeDB.fallback_font,p,t,align,span,px,tint)

func _draw() -> void:
	if hero==null: return
	box(Rect2(29,16,902,390),INK,Color("#a58d63"))
	draw_texture_rect(Icons.get_icon("book"),Rect2(49,31,47,47),false)
	words(Vector2(109,53),"Книга умений",27,PAPER)
	words(Vector2(110,77),"%s  ·  %d SP" % [hero.title(),hero.sp],14,GOLD)
	box(CLOSE,Color("#2b4034"),Color("#65765e"))
	words(CLOSE.position+Vector2(0,27),"Готово",15,PAPER,CLOSE.size.x,HORIZONTAL_ALIGNMENT_CENTER)
	var ids:=catalog.keys()
	for i in ids.size():
		var id: String=ids[i]
		var sk: Dictionary=catalog[id]
		var r:=card_rect(i)
		var available:=allowed(id)
		var selected:bool=chosen==id or (dragging and pressed_id==id)
		box(r,Color("#394b38") if selected else Color("#20362e"),GOLD if selected else Color("#536750"),2 if selected else 1)
		draw_texture_rect(Icons.for_skill(sk),Rect2(r.position+Vector2(10,8),Vector2(49,49)),false,Color.WHITE if available else Color("#818c87"))
		var tag: String="Действие" if not sk.has("index") else ("Ур. %d" % sk.level)
		words(r.position+Vector2(66,29),tag,13,GOLD if available else MUTED)
		var ix: int=hero.hotbar.find(id)
		if ix>=0: words(r.position+Vector2(66,49),"Ячейка %d" % (ix+1),12,MUTED)
		elif not available: words(r.position+Vector2(66,49),"Изучить",12,MUTED)
		words(r.position+Vector2(9,78),sk.name,15,PAPER if available else MUTED,r.size.x-16)
	if chosen!="" and catalog.has(chosen):
		var sk: Dictionary=catalog[chosen]
		words(Vector2(52,334),sk.name,19,GOLD)
		draw_multiline_string(ThemeDB.fallback_font,Vector2(52,359),sk.description,HORIZONTAL_ALIGNMENT_LEFT,637,15,2,MUTED)
		var action_text:=""
		if allowed(chosen) and hero.hotbar.has(chosen): action_text="Убрать с панели"
		elif not allowed(chosen): action_text="Ур. %d · %d SP" % [sk.level,sk.sp] if hero.level()<sk.level else "Изучить · %d SP" % sk.sp
		if action_text!="":
			box(ACTION,Color("#334c3c"),Color("#8c885f"))
			words(ACTION.position+Vector2(0,29),action_text,15,PAPER,ACTION.size.x,HORIZONTAL_ALIGNMENT_CENTER)
	else:
		words(Vector2(52,350),"Перетащи умение на панель внизу",20,PAPER)
		words(Vector2(52,376),"Или коснись умения, затем нужной ячейки.",15,MUTED)
	box(Rect2(159,413,641,121),INK,Color("#736e52"))
	words(Vector2(177,441),status if status!="" else "Панель быстрого доступа",16,GOLD)
	for i in 7:
		var rec: Dictionary=catalog.get(hero.hotbar[i],{})
		Slot.paint(self,Slot.bar_rect(i),i+1,rec,false,dragging and slot_at(current)==i)
	if dragging:
		var ghost:=Rect2(current-Vector2(25,57),Vector2(50,50))
		draw_texture_rect(Icons.for_skill(catalog[pressed_id]),ghost,false)
		draw_rect(ghost,GOLD,false,2)

func _notification(what: int) -> void:
	if what==NOTIFICATION_VISIBILITY_CHANGED or what==NOTIFICATION_APPLICATION_FOCUS_OUT:
		reset_pointer()
