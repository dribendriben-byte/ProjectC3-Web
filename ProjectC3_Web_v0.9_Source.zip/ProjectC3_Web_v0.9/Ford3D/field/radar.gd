extends Control

const Ground = preload("res://ford/ground.gd")
var town:=false
var player := Vector2.ZERO
var creatures := PackedVector2Array()

func mapped(p: Vector2) -> Vector2:
	if town: return ((p-Vector2(180,0))/Vector2(94,80)+Vector2(.5,.5))*size
	return (p/Vector2(40,28)+Vector2(.5,.5))*size

func _draw() -> void:
	draw_rect(Rect2(Vector2.ZERO,size),Color("#526348"))
	if town:
		for x in [-33,-18,0,18,33]: draw_line(mapped(Vector2(180+x,-38)),mapped(Vector2(180+x,38)),Color("#b9a880"),3)
		for z in [-21,3,17,30]: draw_line(mapped(Vector2(135,z)),mapped(Vector2(225,z)),Color("#b9a880"),2)
		draw_circle(mapped(Vector2(180,2)),4,Color("#85b9ba"))
		draw_circle(mapped(Vector2(180,37)),3,Color("#eac784"))
		draw_circle(mapped(player),4,Color("#fff0b3"))
		return
	var line := PackedVector2Array()
	for i in range(-14,15): line.append(mapped(Vector2(Ground.river(i),i)))
	draw_polyline(line,Color("#739fa2"),15,true)
	draw_line(mapped(Vector2(-3,0)),mapped(Vector2(3,0)),Color("#ccad75"),4,true)
	for p in creatures: draw_circle(mapped(p),2,Color("#e6b479"))
	draw_circle(mapped(player),3.6,Color("#fff0b3"))
	draw_rect(Rect2(Vector2.ZERO,size),Color("#aaab83"),false,1)
