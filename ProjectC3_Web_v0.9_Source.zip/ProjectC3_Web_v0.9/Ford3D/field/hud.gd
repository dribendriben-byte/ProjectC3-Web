extends CanvasLayer

signal start_requested(race: String, origin: String)
signal swap_requested(source: int, destination: int)
signal layout_changed
signal sound_requested
signal skill_pressed(slot: int)
signal window_requested(kind: String)
signal train_requested(slot: int)
signal equip_requested(id: String)
signal gateway_pressed
signal transfer_requested(choice: String)
signal careers_pressed
const SkillButton = preload("res://field/skill_button.gd")
const FloatPanel=preload("res://field/floating_panel.gd")
const Icons = preload("res://field/icon_library.gd")
const Careers = preload("res://field/careers.gd")
const Stick = preload("res://field/stick.gd")
const Radar = preload("res://field/radar.gd")
const IVORY := Color("#f2edd9")
const GOLD := Color("#eac382")
var ui := Control.new()
var status: Label
var hp: ProgressBar
var xp: ProgressBar
var progress: Label
var area: Label
var target_name: Label
var feed: Label
var slots: Array[SkillButton] = []
var gateway: Button
var mp: ProgressBar
var veil := ColorRect.new()
var jobs: Button
var stick := Stick.new()
var radar := Radar.new()
var shade := ColorRect.new()
var frame := Panel.new()
var book_editor := preload("res://field/spellbook.gd").new()
var sound_button: Button
var menus := {}
var bar_pointer := -99
var bar_source := -1
var bar_start := Vector2.ZERO
var bar_dragging := false
var drag_ghost := TextureRect.new()
var bag:=FloatPanel.new()
var sheet:=FloatPanel.new()
var desks:=Control.new()
var box := VBoxContainer.new()
var race_select: OptionButton
var origin_select: OptionButton
var preview: Label
var portrait: TextureRect
var playing := false
var enter_button: Button

func place(parent: Node, control: Control, rect: Rect2) -> void:
	parent.add_child(control)
	control.position = rect.position
	control.size = rect.size

func style(color: Color, radius := 6) -> StyleBoxFlat:
	var s := StyleBoxFlat.new()
	s.bg_color = color
	s.set_corner_radius_all(radius)
	s.content_margin_left = 12
	s.content_margin_right = 12
	return s

func panel(rect: Rect2) -> Panel:
	var p := Panel.new()
	p.mouse_filter = Control.MOUSE_FILTER_IGNORE
	p.add_theme_stylebox_override("panel",style(Color("#172823ec")))
	place(ui,p,rect)
	return p

func label(value: String, pixels: int, color := IVORY) -> Label:
	var l := Label.new()
	l.text = value
	l.add_theme_font_size_override("font_size",pixels)
	l.add_theme_color_override("font_color",color)
	l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return l

func button(value: String) -> Button:
	var b := Button.new()
	b.text = value
	b.focus_mode = Control.FOCUS_NONE
	b.add_theme_font_size_override("font_size",16)
	b.add_theme_stylebox_override("normal",style(Color("#345348")))
	b.add_theme_stylebox_override("hover",style(Color("#476654")))
	b.add_theme_stylebox_override("pressed",style(Color("#756445")))
	b.custom_minimum_size.y = 39
	return b

func bar(parent: Control, y: float, color: Color) -> ProgressBar:
	var b := ProgressBar.new()
	b.show_percentage = false
	b.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var fill := style(color,2)
	fill.content_margin_left = 0
	fill.content_margin_right = 0
	b.add_theme_stylebox_override("fill",fill)
	b.add_theme_stylebox_override("background",style(Color("#45534b"),2))
	place(parent,b,Rect2(14,y,268,6))
	return b

func icon_button(id: String, title: String) -> Button:
	var b:=Button.new()
	b.icon=Icons.get_icon(id)
	b.expand_icon=true
	b.icon_alignment=HORIZONTAL_ALIGNMENT_CENTER
	b.tooltip_text=title
	b.accessibility_name=title
	b.focus_mode=Control.FOCUS_NONE
	b.flat=true
	b.mouse_default_cursor_shape=Control.CURSOR_POINTING_HAND
	return b

func _ready() -> void:
	add_child(ui)
	ui.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	ui.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var plate := panel(Rect2(14,12,296,104))
	status = label("",17)
	place(plate,status,Rect2(14,4,269,25))
	hp = bar(plate,34,Color("#cd8976"))
	progress = label("",13,Color("#ded7bb"))
	place(plate,progress,Rect2(14,41,270,23))
	mp = bar(plate,68,Color("#78adce"))
	xp = bar(plate,86,Color("#c6b379"))
	var atlas := panel(Rect2(758,12,188,139))
	area = label("",15,GOLD)
	place(atlas,area,Rect2(12,3,175,28))
	radar.mouse_filter = Control.MOUSE_FILTER_IGNORE
	place(atlas,radar,Rect2(13,35,162,93))
	var log_plate := panel(Rect2(144,421,548,34))
	feed = label("Коснись земли для движения или выбери моба.",14)
	feed.text_overrun_behavior = TextServer.OVERRUN_TRIM_ELLIPSIS
	place(log_plate,feed,Rect2(12,0,525,34))
	place(ui,stick,Rect2(18,412,110,110))
	var target_plate := panel(Rect2(704,419,242,37))
	target_name = label("Выбери цель на поле",15,GOLD)
	place(target_plate,target_name,Rect2(10,0,223,39))
	for i in 7:
		var key := SkillButton.new()
		key.setup(i+1)
		place(ui,key,SkillButton.bar_rect(i))
		key.pressed.connect(func(): skill_pressed.emit(i))
		slots.append(key)
	var names := ["Инвентарь","Умения","Персонаж","Профессии","Звук"]
	var images := ["bag","book","person","career","sound"]
	for i in names.size():
		var tab := icon_button(images[i],names[i])
		place(ui,tab,Rect2(12+(i%3)*57,120+floori(i/3.0)*57,55,55))
		menus[names[i]]=tab
		match names[i]:
			"Профессии":
				jobs=tab
				tab.pressed.connect(func(): careers_pressed.emit())
			"Звук":
				sound_button=tab
				tab.pressed.connect(func(): sound_requested.emit())
			_:
				tab.pressed.connect(func(): window_requested.emit(names[i]))
	gateway = button("Войти")
	place(ui,gateway,Rect2(650,372,295,47))
	gateway.hide()
	gateway.pressed.connect(func(): gateway_pressed.emit())
	place(ui,shade,Rect2(0,0,960,540))
	shade.color = Color("#112019dd")
	frame.add_theme_stylebox_override("panel",style(Color("#20362f"),12))
	place(shade,frame,Rect2(193,39,574,462))
	place(frame,box,Rect2(27,18,520,425))
	box.add_theme_constant_override("separation",8)
	place(ui,desks,Rect2(0,0,960,540))
	ui.move_child(desks,shade.get_index())
	desks.mouse_filter=Control.MOUSE_FILTER_IGNORE
	for panel_ in [bag,sheet]:
		desks.add_child(panel_)
		panel_.init(panel_==sheet)
		panel_.equip.connect(func(id): equip_requested.emit(id))
	bag.peer=sheet
	sheet.peer=bag
	bag.position=Vector2(554,51)
	sheet.position=Vector2(172,35)
	place(shade,book_editor,Rect2(0,0,960,540))
	book_editor.hide()
	book_editor.closed.connect(shade.hide)
	book_editor.changed.connect(func(): layout_changed.emit())
	book_editor.learn_requested.connect(func(i): train_requested.emit(i))
	place(ui,veil,Rect2(0,0,960,540))
	veil.color = Color(0.08,0.13,0.12,1)
	veil.hide()
	drag_ghost.mouse_filter=Control.MOUSE_FILTER_IGNORE
	drag_ghost.expand_mode=TextureRect.EXPAND_IGNORE_SIZE
	place(ui,drag_ghost,Rect2(0,0,49,49))
	drag_ghost.hide()
	shade.visibility_changed.connect(cancel_bar_drag)

func clear_menu() -> void:
	book_editor.hide()
	frame.show()
	for child in box.get_children():
		box.remove_child(child)
		child.queue_free()
	stick.reset()
	shade.show()

func picker() -> OptionButton:
	var o := OptionButton.new()
	o.custom_minimum_size.y = 43
	o.add_theme_font_size_override("font_size",17)
	box.add_child(o)
	return o

func show_creation() -> void:
	clear_menu()
	var header := HBoxContainer.new()
	box.add_child(header)
	portrait = TextureRect.new()
	portrait.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	portrait.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	portrait.custom_minimum_size = Vector2(48,52)
	header.add_child(portrait)
	header.add_child(label("ЗЕМЛИ ЗАСТАВЫ",15,GOLD))
	box.add_child(label("Выбор персонажа",32))
	box.add_child(label("Раса",15))
	race_select = picker()
	for r in Careers.TREE: race_select.add_item(r)
	box.add_child(label("Стартовый класс",15))
	origin_select = picker()
	preview = label("",15,Color("#cfdbbf"))
	preview.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	preview.custom_minimum_size.y = 66
	box.add_child(preview)
	race_select.item_selected.connect(func(_i): _origins())
	origin_select.item_selected.connect(func(_i): _preview())
	enter_button = button("Войти в мир")
	box.add_child(enter_button)
	_origins()
	enter_button.pressed.connect(func(): start_requested.emit(race_select.get_item_text(race_select.selected),origin_select.get_item_text(origin_select.selected)))

func _origins() -> void:
	origin_select.clear()
	for o in Careers.TREE[race_select.get_item_text(race_select.selected)]:
		origin_select.add_item(o)
	_preview()

func _preview() -> void:
	var r := race_select.get_item_text(race_select.selected)
	var o := origin_select.get_item_text(origin_select.selected)
	portrait.texture = Careers.SKINS[race_select.selected][origin_select.selected]
	var slot := Careers.new()
	slot.race = r
	slot.origin = o
	enter_button.text = "Продолжить · Ур. %d" % slot.level() if slot.restore() else "Войти в мир"
	var attack := "Дальняя атака чарами" if origin_select.selected == 1 else "Ближний бой"
	preview.text = "%s. Профессии на ур. 20\n%s" % [attack,", ".join(Careers.TREE[r][o].keys())]

func show_careers(hero: Careers) -> void:
	clear_menu()
	box.add_child(label("%s   /   Ур. %d" % [hero.race,hero.level()],15,GOLD))
	box.add_child(label(hero.title(),30))
	var branches: Dictionary = Careers.TREE[hero.race][hero.origin]
	for f in branches:
		var row := label("20 · %s   →   40 · %s" % [f,", ".join(branches[f])],15)
		row.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		box.add_child(row)
	if not hero.choices().is_empty():
		box.add_child(label("Выбери профессию",16,GOLD))
		for c in hero.choices():
			var b := button(c)
			box.add_child(b)
			b.pressed.connect(func(): transfer_requested.emit(c))
	var close := button("Вернуться в мир")
	box.add_child(close)
	close.pressed.connect(shade.hide)

func refresh(hero: Careers, health: int, mana: int, sector_name: String) -> void:
	status.text = "%s · Ур. %d" % [hero.title(),hero.level()]
	hp.max_value = hero.hp_max()
	hp.value = health
	mp.max_value = hero.mana_max()
	mp.value = mana
	var lv := hero.level()
	var from_xp: int = hero.Experience.START[lv-1]
	var next_xp: int = hero.Experience.START[mini(lv,74)]
	xp.max_value = maxi(1,next_xp-from_xp)
	xp.value = xp.max_value if lv==75 else hero.total_xp-from_xp
	progress.text = "ОЗ %d/%d   МП %d/%d   EXP %.1f%%" % [health,hero.hp_max(),mana,hero.mana_max(),100*xp.ratio]
	area.text = sector_name
	jobs.tooltip_text = "Выбрать профессию" if not hero.choices().is_empty() else "Профессии"

func show_panel(title: String) -> VBoxContainer:
	clear_menu()
	box.add_child(label(title,30,GOLD))
	var scroll := ScrollContainer.new()
	scroll.custom_minimum_size = Vector2(515,300)
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	box.add_child(scroll)
	var rows := VBoxContainer.new()
	rows.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	rows.add_theme_constant_override("separation",7)
	scroll.add_child(rows)
	var close := button("Вернуться в мир")
	close.pressed.connect(shade.hide)
	box.add_child(close)
	return rows

func show_stats(hero: Careers,health: int,mana: int,_speed: float) -> void:
	sheet.stats={"hp":health,"mp":mana,"str":hero.strength(),"dex":hero.dexterity()}
	if sheet.visible: sheet.hide()
	else: sheet.present(hero)

func show_bag(hero: Careers) -> void:
	if bag.visible: bag.hide()
	else: bag.present(hero)

func panels_cover(p: Vector2) -> bool:
	return (sheet.visible and sheet.get_rect().has_point(p)) or (bag.visible and bag.get_rect().has_point(p))

func show_book(hero: Careers, catalog: Dictionary) -> void:
	stick.reset()
	frame.hide()
	shade.show()
	book_editor.present(hero,catalog)

func bar_at(p: Vector2) -> int:
	for i in slots.size():
		if SkillButton.bar_rect(i).has_point(p): return i
	return -1

func cancel_bar_drag() -> void:
	bar_pointer=-99
	bar_source=-1
	bar_dragging=false
	drag_ghost.hide()

func bar_gesture(e: InputEvent) -> bool:
	var id: int
	if e is InputEventScreenTouch or e is InputEventScreenDrag: id=e.index
	elif e is InputEventMouseButton or e is InputEventMouseMotion:
		id=-1
		if e is InputEventMouseButton and e.button_index!=MOUSE_BUTTON_LEFT: return false
		if e.device==InputEvent.DEVICE_ID_EMULATION:
			return bar_pointer!=-99 or bar_at(ui.get_global_transform_with_canvas().affine_inverse()*e.position)>=0
	else: return false
	var p: Vector2=ui.get_global_transform_with_canvas().affine_inverse()*e.position
	if bar_pointer==-99 and panels_cover(p): return false
	var to:=bar_at(p)
	if e is InputEventScreenTouch or e is InputEventMouseButton:
		if e.pressed:
			if to<0 or bar_pointer!=-99: return false
			bar_pointer=id
			bar_source=to
			bar_start=p
			return true
		if id!=bar_pointer: return false
		var source:=bar_source
		var moved:=bar_dragging or p.distance_to(bar_start)>9
		cancel_bar_drag()
		if not e.canceled and to>=0:
			if moved and to!=source: swap_requested.emit(source,to)
			elif not moved and to==source: skill_pressed.emit(source)
		return true
	if id!=bar_pointer: return false
	if p.distance_to(bar_start)>9:
		bar_dragging=true
		if not slots[bar_source].entry.is_empty():
			drag_ghost.texture=Icons.for_skill(slots[bar_source].entry)
			drag_ghost.position=p-Vector2(24,54)
			drag_ghost.show()
	return true

func _notification(what: int) -> void:
	if what==NOTIFICATION_APPLICATION_FOCUS_OUT: cancel_bar_drag()

func _input(event: InputEvent) -> void:
	if playing and not shade.visible and bar_gesture(event):
		get_viewport().set_input_as_handled()
		return
	if playing and not shade.visible and event is InputEventKey and event.pressed and event.keycode==KEY_ESCAPE:
		for i in range(desks.get_child_count()-1,-1,-1):
			var panel_=desks.get_child(i)
			if panel_.visible:
				panel_.hide()
				get_viewport().set_input_as_handled()
				return
	if playing and shade.visible and event is InputEventKey and event.pressed and not event.echo and event.keycode==KEY_ESCAPE:
		shade.hide()
		get_viewport().set_input_as_handled()
