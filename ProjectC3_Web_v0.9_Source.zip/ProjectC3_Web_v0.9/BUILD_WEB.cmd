@echo off
setlocal
cd /d "%~dp0"
echo PROJECT C3 - Web export
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\build_web.ps1" %*
if errorlevel 1 echo Build failed. See the messages above.
pause
