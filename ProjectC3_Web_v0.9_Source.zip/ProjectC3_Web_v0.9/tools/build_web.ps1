param([string]$Godot)
$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
$project = Join-Path $root 'Ford3D'
$build = Join-Path $root 'C3_WEB_BUILD'
try {
    if (-not $Godot) {
        $cmd = Get-Command godot, godot4 -ErrorAction SilentlyContinue | Select-Object -First 1
        if ($cmd) { $Godot = $cmd.Source }
    }
    if (-not $Godot) {
        Add-Type -AssemblyName System.Windows.Forms
        $dialog = New-Object System.Windows.Forms.OpenFileDialog
        $dialog.Title = 'Select Godot 4.7.2 Standard executable (console exe preferred)'
        $dialog.Filter = 'Godot executable (*.exe)|*.exe'
        if ($dialog.ShowDialog() -ne 'OK') { throw 'Godot executable was not selected.' }
        $Godot = $dialog.FileName
    }
    if (-not (Test-Path -LiteralPath $Godot -PathType Leaf)) { throw 'Godot executable not found.' }
    $Godot = (Resolve-Path -LiteralPath $Godot).Path
    if (-not $Godot.EndsWith('_console.exe')) {
        $console = [IO.Path]::Combine([IO.Path]::GetDirectoryName($Godot),[IO.Path]::GetFileNameWithoutExtension($Godot)+'_console.exe')
        if (Test-Path -LiteralPath $console) { $Godot=$console }
    }
    & $Godot --version
    if ($LASTEXITCODE -ne 0) { throw 'Godot did not run.' }
    New-Item -ItemType Directory -Path $build -Force | Out-Null
    # Remove only known previous export files, never saves or project source.
    Get-ChildItem -LiteralPath $build -File | Where-Object { $_.Name -like 'index.*' } | Remove-Item -Force
    & $Godot --headless --path $project --editor --import
    if ($LASTEXITCODE -ne 0) { throw 'Resource import failed.' }
    $html = Join-Path $build 'index.html'
    & $Godot --headless --path $project --export-release Web $html
    if ($LASTEXITCODE -ne 0) { throw 'Web export failed. Install matching export templates in Godot: Editor > Manage Export Templates.' }
    foreach ($name in @('index.html','index.js','index.wasm','index.pck')) {
        $file = Join-Path $build $name
        if (!(Test-Path -LiteralPath $file -PathType Leaf) -or (Get-Item -LiteralPath $file).Length -eq 0) { throw "Missing output: $name. Check the Godot export log and templates." }
    }
    if ((Get-Content -LiteralPath $html -Raw).Contains('$GODOT_CONFIG')) { throw 'HTML template was not processed.' }
    $zip = Join-Path $root 'ProjectC3_Web_PLAYABLE.zip'
    Compress-Archive -Path (Join-Path $build '*') -DestinationPath $zip -Force
    Write-Host "SUCCESS: $zip" -ForegroundColor Green
    Write-Host 'Upload the ZIP to itch.io as an HTML game, or run PLAY_LOCAL.cmd to test it first.'
} catch { Write-Host $_.Exception.Message -ForegroundColor Red; exit 1 }
