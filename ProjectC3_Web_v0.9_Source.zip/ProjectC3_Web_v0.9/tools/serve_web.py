from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from functools import partial
import webbrowser

build = Path(__file__).resolve().parents[1] / "C3_WEB_BUILD"
if not all((build / n).is_file() for n in ("index.html", "index.js", "index.wasm", "index.pck")):
    raise SystemExit("Run BUILD_WEB.cmd first or export the Web preset in Godot.")

class Handler(SimpleHTTPRequestHandler):
    extensions_map = {**SimpleHTTPRequestHandler.extensions_map, ".wasm": "application/wasm", ".pck": "application/octet-stream", ".js": "text/javascript"}
    def end_headers(self):
        self.send_header("Cache-Control", "no-store")
        super().end_headers()

url = "http://127.0.0.1:8060/"
with ThreadingHTTPServer(("127.0.0.1", 8060), partial(Handler, directory=str(build))) as server:
    print("Open " + url + " (Ctrl+C to stop)", flush=True)
    webbrowser.open(url)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
